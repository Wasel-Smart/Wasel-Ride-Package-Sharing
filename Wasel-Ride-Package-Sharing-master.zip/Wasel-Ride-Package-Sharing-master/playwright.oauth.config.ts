import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  testDir: './e2e',
  testMatch: ['oauth.spec.ts'],
  timeout: 60_000,
  workers: 1,
  fullyParallel: false,
  expect: {
    timeout: 10_000,
  },
  use: {
    baseURL: 'http://127.0.0.1:4173',
    trace: 'retain-on-failure',
  },
  webServer:
    process.env.PLAYWRIGHT_EXTERNAL_SERVER === 'true'
      ? undefined
      : {
          command: 'node scripts/start-playwright-dev.mjs',
          url: 'http://127.0.0.1:4173',
          reuseExistingServer: false,
          timeout: 900_000,
        },
  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },
  ],
});
