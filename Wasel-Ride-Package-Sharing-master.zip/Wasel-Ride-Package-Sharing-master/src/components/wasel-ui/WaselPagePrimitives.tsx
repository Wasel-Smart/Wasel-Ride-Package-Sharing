import type { CSSProperties, ReactNode } from 'react';
import { ChevronRight, type LucideIcon } from 'lucide-react';
import { ANIM, C, F, FA, GRAD_HERO, R, SH, SPACE, TYPE } from '../../utils/wasel-ds';

interface PageShellProps {
  children: ReactNode;
  maxWidth?: number;
  padded?: boolean;
  style?: CSSProperties;
  dir?: 'ltr' | 'rtl';
}

interface PageHeroProps {
  icon?: ReactNode;
  eyebrow?: string;
  title: string;
  description?: string;
  accent?: string;
  actions?: ReactNode;
  aside?: ReactNode;
}

interface SectionCardProps {
  title: string;
  subtitle?: string;
  icon?: ReactNode;
  children: ReactNode;
  action?: ReactNode;
  contentPadding?: string;
}

interface MetricCardProps {
  label: string;
  value: string | number;
  detail?: string;
  accent?: string;
  icon?: ReactNode;
}

interface ActionTileProps {
  label: string;
  detail?: string;
  icon?: ReactNode;
  accent?: string;
  onClick?: () => void;
}

interface DataRowProps {
  label: string;
  value?: string;
  sub?: string;
  icon?: ReactNode;
  badge?: ReactNode;
  onClick?: () => void;
  danger?: boolean;
}

export function PageShell({
  children,
  maxWidth = 1120,
  padded = true,
  style,
  dir = 'ltr',
}: PageShellProps) {
  return (
    <div
      style={{
        minHeight: 'var(--app-min-height)',
        background: `linear-gradient(180deg, ${C.bgDeep} 0%, ${C.bg} 38%, ${C.bgAlt} 100%)`,
        color: C.text,
        fontFamily: dir === 'rtl' ? FA : F,
        direction: dir,
        position: 'relative',
        paddingBottom: 96,
        ...style,
      }}
    >
      <div
        aria-hidden="true"
        style={{
          position: 'fixed',
          inset: 0,
          pointerEvents: 'none',
          backgroundImage: `linear-gradient(${C.borderFaint} 1px, transparent 1px), linear-gradient(90deg, ${C.borderFaint} 1px, transparent 1px)`,
          backgroundSize: '80px 80px',
          maskImage:
            'linear-gradient(180deg, transparent 0%, black 14%, black 78%, transparent 100%)',
          opacity: 0.09,
        }}
      />
      <div
        className="wasel-container"
        style={{
          position: 'relative',
          maxWidth,
          margin: '0 auto',
          paddingTop: padded ? SPACE[7] : 0,
          paddingBottom: padded ? SPACE[7] : 0,
        }}
      >
        {children}
      </div>
    </div>
  );
}

export function PageHero({
  icon,
  eyebrow,
  title,
  description,
  accent = C.cyan,
  actions,
  aside,
}: PageHeroProps) {
  return (
    <div
      style={{
        position: 'relative',
        overflow: 'hidden',
        display: 'grid',
        gridTemplateColumns: aside ? 'repeat(auto-fit, minmax(min(100%, 300px), 1fr))' : '1fr',
        gap: SPACE[5],
        padding: `${SPACE[7]} ${SPACE[6]}`,
        borderRadius: R.xxl,
        background: `
          linear-gradient(135deg, ${accent}12, transparent 34%),
          ${GRAD_HERO}
        `,
        border: `1px solid ${C.border}`,
        boxShadow: SH.md,
        marginBottom: SPACE[6],
      }}
    >
      <div
        aria-hidden="true"
        style={{
          position: 'absolute',
          inset: 0,
          background: `linear-gradient(120deg, ${C.elevated}, transparent 32%, transparent 72%, ${C.borderFaint})`,
          pointerEvents: 'none',
        }}
      />
      <div style={{ position: 'relative', minWidth: 0 }}>
        {eyebrow ? (
          <div
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: 8,
              padding: '6px 12px',
              borderRadius: R.full,
              background: `${accent}12`,
              border: `1px solid ${accent}24`,
              color: accent,
              fontSize: TYPE.size.xs,
              fontWeight: TYPE.weight.bold,
              textTransform: 'uppercase',
              letterSpacing: 0,
              marginBottom: SPACE[4],
            }}
          >
            {icon}
            {eyebrow}
          </div>
        ) : null}
        <h1
          style={{
            margin: 0,
            fontSize: '2.65rem',
            lineHeight: TYPE.lineHeight.tight,
            letterSpacing: 0,
            fontWeight: TYPE.weight.ultra,
            color: C.text,
            maxWidth: 760,
          }}
        >
          {title}
        </h1>
        {description ? (
          <p
            style={{
              margin: `${SPACE[4]} 0 0`,
              maxWidth: 760,
              color: C.textMuted,
              fontSize: TYPE.size.base,
              lineHeight: TYPE.lineHeight.relaxed,
            }}
          >
            {description}
          </p>
        ) : null}
        {actions ? (
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: SPACE[3], marginTop: SPACE[5] }}>
            {actions}
          </div>
        ) : null}
      </div>
      {aside ? (
        <div
          style={{
            position: 'relative',
            minWidth: 0,
            borderRadius: R.xl,
            background: C.elevated,
            border: `1px solid ${C.border}`,
            boxShadow: SH.sm,
            padding: SPACE[4],
            alignSelf: 'stretch',
          }}
        >
          {aside}
        </div>
      ) : null}
    </div>
  );
}

export function SectionCard({
  title,
  subtitle,
  icon,
  children,
  action,
  contentPadding = SPACE[5],
}: SectionCardProps) {
  return (
    <section style={{ marginBottom: SPACE[6] }}>
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          gap: SPACE[4],
          marginBottom: SPACE[2],
        }}
      >
        <div style={{ minWidth: 0 }}>
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: SPACE[2],
              color: C.text,
              fontSize: TYPE.size.base,
              fontWeight: TYPE.weight.black,
              letterSpacing: 0,
            }}
          >
            {icon}
            <span>{title}</span>
          </div>
          {subtitle ? (
            <p
              style={{
                margin: '6px 0 0',
                color: C.textMuted,
                fontSize: TYPE.size.sm,
                lineHeight: TYPE.lineHeight.relaxed,
              }}
            >
              {subtitle}
            </p>
          ) : null}
        </div>
        {action}
      </div>
      <div
        style={{
          background: `linear-gradient(180deg, ${C.card}, rgba(9,22,34,0.92))`,
          border: `1px solid ${C.border}`,
          borderRadius: R.xl,
          boxShadow: SH.sm,
          overflow: 'hidden',
        }}
      >
        <div style={{ padding: contentPadding }}>{children}</div>
      </div>
    </section>
  );
}

export function MetricCard({ label, value, detail, accent = C.cyan, icon }: MetricCardProps) {
  return (
    <div
      className="wasel-card"
      style={{
        minWidth: 0,
        padding: `${SPACE[4]} ${SPACE[4]}`,
        borderColor: `${accent}24`,
        borderStyle: 'solid',
        borderWidth: 1,
        borderRadius: R.xl,
        background: `linear-gradient(180deg, ${C.card}, rgba(9,22,34,0.92))`,
        boxShadow: SH.sm,
      }}
    >
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          gap: SPACE[3],
          marginBottom: SPACE[3],
        }}
      >
        <span
          style={{
            display: 'inline-flex',
            alignItems: 'center',
            justifyContent: 'center',
            width: 40,
            height: 40,
            borderRadius: R.md,
            color: accent,
            background: `${accent}18`,
            border: `1px solid ${accent}28`,
            flexShrink: 0,
          }}
        >
          {icon}
        </span>
        <span
          style={{
            fontSize: TYPE.size.xs,
            fontWeight: TYPE.weight.bold,
            letterSpacing: 0,
            textTransform: 'uppercase',
            color: C.textMuted,
          }}
        >
          {label}
        </span>
      </div>
      <div
        style={{
          color: C.text,
          fontSize: TYPE.size['2xl'],
          fontWeight: TYPE.weight.ultra,
          lineHeight: TYPE.lineHeight.tight,
        }}
      >
        {value}
      </div>
      {detail ? (
        <div
          style={{
            marginTop: SPACE[2],
            color: C.textMuted,
            fontSize: TYPE.size.sm,
            lineHeight: TYPE.lineHeight.relaxed,
          }}
        >
          {detail}
        </div>
      ) : null}
    </div>
  );
}

export function ActionTile({ label, detail, icon, accent = C.cyan, onClick }: ActionTileProps) {
  const clickable = Boolean(onClick);
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={!clickable}
      style={{
        width: '100%',
        padding: `${SPACE[4]} ${SPACE[4]}`,
        borderRadius: R.xl,
        border: `1px solid ${accent}1f`,
        background: C.card,
        color: C.text,
        cursor: clickable ? 'pointer' : 'default',
        textAlign: 'left',
        transition: `transform ${ANIM.dur.normal} ${ANIM.ease.default}, border-color ${ANIM.dur.normal} ${ANIM.ease.default}, box-shadow ${ANIM.dur.normal} ${ANIM.ease.default}`,
        boxShadow: SH.sm,
      }}
      onMouseEnter={event => {
        if (!clickable) return;
        event.currentTarget.style.transform = 'translateY(-2px)';
        event.currentTarget.style.borderColor = `${accent}36`;
        event.currentTarget.style.boxShadow = SH.lg;
      }}
      onMouseLeave={event => {
        event.currentTarget.style.transform = '';
        event.currentTarget.style.borderColor = `${accent}1f`;
        event.currentTarget.style.boxShadow = SH.md;
      }}
    >
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          gap: SPACE[3],
        }}
      >
        <span
          style={{
            display: 'inline-flex',
            alignItems: 'center',
            justifyContent: 'center',
            width: 40,
            height: 40,
            borderRadius: R.md,
            color: accent,
            background: `${accent}14`,
            border: `1px solid ${accent}24`,
            flexShrink: 0,
          }}
        >
          {icon}
        </span>
        <ChevronRight size={16} color={C.textDim} />
      </div>
      <div
        style={{
          marginTop: SPACE[4],
          fontSize: TYPE.size.base,
          fontWeight: TYPE.weight.bold,
          color: C.text,
        }}
      >
        {label}
      </div>
      {detail ? (
        <div
          style={{
            marginTop: SPACE[2],
            fontSize: TYPE.size.sm,
            lineHeight: TYPE.lineHeight.relaxed,
            color: C.textMuted,
          }}
        >
          {detail}
        </div>
      ) : null}
    </button>
  );
}

export function DataRow({ label, value, sub, icon, badge, onClick, danger = false }: DataRowProps) {
  const accent = danger ? C.error : C.cyan;
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={!onClick}
      style={{
        width: '100%',
        display: 'flex',
        alignItems: 'center',
        gap: SPACE[3],
        padding: `${SPACE[4]} ${SPACE[4]}`,
        background: 'transparent',
        border: 'none',
        borderBottom: `1px solid ${C.borderFaint}`,
        textAlign: 'left',
        cursor: onClick ? 'pointer' : 'default',
        transition: `background ${ANIM.dur.normal} ${ANIM.ease.default}`,
      }}
      onMouseEnter={event => {
        if (onClick) event.currentTarget.style.background = C.elevated;
      }}
      onMouseLeave={event => {
        event.currentTarget.style.background = 'transparent';
      }}
    >
      {icon ? (
        <span
          style={{
            display: 'inline-flex',
            alignItems: 'center',
            justifyContent: 'center',
            width: 36,
            height: 36,
            borderRadius: R.md,
            background: `${accent}14`,
            border: `1px solid ${accent}22`,
            color: accent,
            flexShrink: 0,
          }}
        >
          {icon}
        </span>
      ) : null}
      <div style={{ flex: 1, minWidth: 0 }}>
        <div
          style={{
            color: danger ? C.error : C.text,
            fontSize: TYPE.size.base,
            fontWeight: TYPE.weight.semibold,
          }}
        >
          {label}
        </div>
        {value ? (
          <div style={{ marginTop: 3, color: C.textMuted, fontSize: TYPE.size.sm }}>{value}</div>
        ) : null}
        {sub ? (
          <div
            style={{
              marginTop: 4,
              color: C.textDim,
              fontSize: TYPE.size.xs,
              lineHeight: TYPE.lineHeight.relaxed,
            }}
          >
            {sub}
          </div>
        ) : null}
      </div>
      {badge}
      {onClick ? <ChevronRight size={16} color={C.textDim} style={{ flexShrink: 0 }} /> : null}
    </button>
  );
}

export function StatusBadge({ label, accent = C.cyan }: { label: string; accent?: string }) {
  return (
    <span
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: 6,
        padding: '4px 10px',
        borderRadius: R.full,
        background: `${accent}12`,
        border: `1px solid ${accent}24`,
        color: accent,
        fontSize: TYPE.size.xs,
        fontWeight: TYPE.weight.bold,
        letterSpacing: TYPE.letterSpacing.normal,
        whiteSpace: 'nowrap',
      }}
    >
      {label}
    </span>
  );
}

export function iconNode(Icon: LucideIcon, color: string) {
  return <Icon size={18} color={color} />;
}
