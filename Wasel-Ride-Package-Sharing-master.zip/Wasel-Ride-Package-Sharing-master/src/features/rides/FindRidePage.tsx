import { useCallback, useEffect, useMemo, useState } from 'react';
import { useLocation } from 'react-router';
import { AnimatePresence, motion } from 'motion/react';
import { useRideFilters } from './hooks/useRideFilters';
import {
  Brain,
  Calendar,
  CheckCircle2,
  Network,
  Search,
  Shield,
  Sparkles,
  TrendingUp,
} from 'lucide-react';
import { MapWrapper } from '../../components/MapWrapper';
import { useLanguage } from '../../contexts/LanguageContext';
import { useLocalAuth } from '../../contexts/LocalAuth';
import { useIframeSafeNavigate } from '../../hooks/useIframeSafeNavigate';
import { usePushNotifications } from '../../hooks/usePushNotifications';
import {
  createDemandAlert,
  getDemandStats,
  hydrateDemandAlerts,
} from '../../services/demandCapture';
import { trackGrowthEvent } from '../../services/growthEngine';
import { getConnectedRides } from '../../services/journeyLogistics';
import { getMovementPriceQuote } from '../../services/movementPricing';
import { recordMovementActivity } from '../../services/movementMembership';
import {
  createReminderFromSuggestion,
  formatRouteReminderSchedule,
  getRecurringRouteSuggestions,
  getRouteReminderForCorridor,
  getRouteReminders,
  syncRouteReminders,
} from '../../services/movementRetention';
import { notificationsAPI } from '../../services/notifications.js';
import { subscribeToRideBookingRealtime } from '../../services/rideRealtime';
import {
  getLiveCorridorSignal,
  useLiveRouteIntelligence,
} from '../../services/routeDemandIntelligence';
import {
  createRideBooking,
  getRideBookings,
  updateRideBooking,
  type RideBookingRecord,
} from '../../services/rideLifecycle';
import { walletApi } from '../../services/walletApi';
import { getCorridorOpportunity, getMarketplaceNodes } from '../../config/wasel-movement-network';
import {
  CITIES,
  RIDE_BOOKINGS_KEY,
  RIDE_SEARCHES_KEY,
  type Ride,
} from '../../pages/waselCoreRideData';
import {
  createFindRideCopy,
  parseFindRideParams,
  scoreRideForRecommendation,
} from '../../pages/waselCorePageHelpers';
import { readStoredStringList, writeStoredStringList } from '../../pages/waselCoreStorage';
import {
  DS,
  midpoint,
  PageShell,
  pill,
  Protected,
  r,
  resolveCityCoord,
  SectionHead,
} from '../../pages/waselServiceShared';
import { WaselButton, WaselInput, WaselSelect } from '../../components/wasel-ui';
import { C } from '../../utils/wasel-ds';
import { ServiceFlowPlaybook } from '../shared/ServiceFlowPlaybook';
import { FindRideCard } from './components/FindRideCard';
import { FindRidePackagePanel } from './components/FindRidePackagePanel';
import { FindRideTripDetailModal } from './components/FindRideTripDetailModal';
import { getFindRideStaticCopy } from './findRideContent';
import { useRideInventory } from './useRideInventory';

type BookingSuccessState = {
  status: 'pending_driver' | 'confirmed';
  routeLabel: string;
  driverName: string;
  priceJod: number;
  ticketCode?: string;
};

export function FindRidePage() {
  const nav = useIframeSafeNavigate();
  const location = useLocation();
  const { user } = useLocalAuth();
  const { language } = useLanguage();
  const ar = language === 'ar';
  const { notifyTripConfirmed, requestPermission, permission } = usePushNotifications();
  const { initialFrom, initialTo, initialDate, initialSearched } = parseFindRideParams(
    location.search,
  );
  const t = createFindRideCopy(ar);
  const copy = getFindRideStaticCopy(ar);

  const [tab, setTab] = useState<'ride' | 'package'>('ride');
  const [from, setFrom] = useState(initialFrom);
  const [to, setTo] = useState(initialTo);
  const [date, setDate] = useState(initialDate);
  const [searched, setSearched] = useState(initialSearched);
  const [loading, setLoading] = useState(false);
  const [selected, setSelected] = useState<Ride | null>(null);
  const [bookingInFlightId, setBookingInFlightId] = useState<string | null>(null);
  const [rideBookings, setRideBookings] = useState<RideBookingRecord[]>(() => getRideBookings());
  const [recentSearches, setRecentSearches] = useState<string[]>(() =>
    readStoredStringList(RIDE_SEARCHES_KEY),
  );
  const [searchError, setSearchError] = useState<string | null>(null);
  const [bookingMessage, setBookingMessage] = useState<string | null>(null);
  const [bookingSuccess, setBookingSuccess] = useState<BookingSuccessState | null>(null);
  const [waitlistMessage, setWaitlistMessage] = useState<string | null>(null);
  const [retentionMessage, setRetentionMessage] = useState<string | null>(null);
  const [savedReminders, setSavedReminders] = useState(() => getRouteReminders());
  const [pkg, setPkg] = useState({
    from: 'Amman',
    to: 'Aqaba',
    weight: '<1 kg',
    note: '',
    sent: false,
  });

  const marketplaceNodes = useMemo(() => getMarketplaceNodes().slice(0, 3), []);
  const corridorPlan = useMemo(() => getCorridorOpportunity(from, to), [from, to]);
  const routeIntelligence = useLiveRouteIntelligence({ from, to });
  const selectedSignal = routeIntelligence.selectedSignal;
  const featuredSignals = routeIntelligence.featuredSignals.slice(0, 4);
  const recurringSuggestions = useMemo(
    () => getRecurringRouteSuggestions(3),
    [routeIntelligence.updatedAt],
  );
  const bookingByRideId = useMemo(() => {
    const next = new Map<string, RideBookingRecord>();

    for (const booking of rideBookings) {
      if (booking.status !== 'pending_driver' && booking.status !== 'confirmed') {
        continue;
      }

      const current = next.get(booking.rideId);
      if (
        !current ||
        new Date(current.updatedAt).getTime() < new Date(booking.updatedAt).getTime()
      ) {
        next.set(booking.rideId, booking);
      }
    }

    return next;
  }, [rideBookings]);
  const bookedRideIds = useMemo(() => new Set(bookingByRideId.keys()), [bookingByRideId]);
  const signalLookup = useMemo(() => {
    const lookup = new Map<string, ReturnType<typeof getLiveCorridorSignal>>();
    for (const signal of routeIntelligence.allSignals) {
      lookup.set(`${signal.from}::${signal.to}`, signal);
      lookup.set(`${signal.to}::${signal.from}`, signal);
    }
    return lookup;
  }, [routeIntelligence.updatedAt]);
  const demandStats = getDemandStats();

  const searchFromCoord = resolveCityCoord(from);
  const searchToCoord = resolveCityCoord(to);
  // Live inventory from Supabase, merged with local posts and static seed.
  const { rides: allAvailableRides, loading: inventoryLoading } = useRideInventory({ from, to, date, searched });
  const corridorRides = allAvailableRides.filter(ride => ride.from === from && ride.to === to);
  const nearbyCorridors = allAvailableRides
    .filter(
      ride =>
        ride.id &&
        !(ride.from === from && ride.to === to) &&
        (ride.from === from || ride.to === to || ride.to === from || ride.from === to),
    )
    .slice(0, 3);

  const filteredResults: Ride[] = searched
    ? allAvailableRides.filter(
      ride =>
        (!from ||
          ride.from.toLowerCase().includes(from.toLowerCase()) ||
          ride.fromAr === from) &&
        (!to || ride.to.toLowerCase().includes(to.toLowerCase()) || ride.toAr === to) &&
        (!date || ride.date === date),
    )
    : allAvailableRides.slice(0, 4);

  const { sort, setSort, sortedRides: results } = useRideFilters(filteredResults);

  const recommendedRides = [...results]
    .sort((left, right) => scoreRideForRecommendation(right) - scoreRideForRecommendation(left))
    .slice(0, 2);
  const bookedRides = allAvailableRides.filter(ride => bookedRideIds.has(ride.id)).slice(0, 3);
  const selectedPriceQuote =
    selectedSignal?.priceQuote ??
    (corridorPlan
      ? getMovementPriceQuote({
        basePriceJod: corridorPlan.sharedPriceJod,
        corridorId: corridorPlan.id,
        forecastDemandScore: corridorPlan.predictedDemandScore,
        membership: routeIntelligence.membership,
      })
      : null);

  const resolveSignalForRoute = (routeFrom: string, routeTo: string) =>
    signalLookup.get(`${routeFrom}::${routeTo}`) ??
    getLiveCorridorSignal(routeFrom, routeTo, routeIntelligence.membership);
  const openMyTrips = useCallback(() => nav('/app/my-trips?tab=rides'), [nav]);
  const selectedBooking = selected ? (bookingByRideId.get(selected.id) ?? null) : null;
  const getRideBookingStatus = useCallback((rideId: string): 'pending_driver' | 'confirmed' | null => {
    const status = bookingByRideId.get(rideId)?.status;
    return status === 'pending_driver' || status === 'confirmed' ? status : null;
  }, [bookingByRideId]);

  useEffect(() => {
    if (!user?.id) return;
    const unsubscribe = subscribeToRideBookingRealtime({
      userId: user.id,
      rides: getConnectedRides(),
      onBookingsChange: setRideBookings,
    });
    void hydrateDemandAlerts(user.id);
    return unsubscribe;
  }, [user?.id]);

  useEffect(() => {
    setSavedReminders(getRouteReminders());
    void syncRouteReminders(user ?? undefined).then(delivered => {
      if (delivered.length > 0) setSavedReminders(getRouteReminders());
    });
  }, [routeIntelligence.updatedAt, user?.email, user?.phone]);

  useEffect(() => {
    writeStoredStringList(RIDE_BOOKINGS_KEY, Array.from(bookedRideIds));
  }, [bookedRideIds]);

  useEffect(() => {
    writeStoredStringList(RIDE_SEARCHES_KEY, recentSearches);
  }, [recentSearches]);

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const nextFrom = CITIES.includes(params.get('from') ?? '') ? (params.get('from') as string) : 'Amman';
    const nextTo = CITIES.includes(params.get('to') ?? '') ? (params.get('to') as string) : 'Aqaba';
    const nextDate = params.get('date') ?? '';
    const nextSearched = params.get('search') === '1';
    setFrom(nextFrom);
    setTo(nextTo);
    setDate(nextDate);
    setSearched(nextSearched);
  }, [location.search]);

  const handleSearch = () => {
    if (from === to) {
      setSearchError(t.chooseDifferentCities);
      setSearched(false);
      return;
    }

    setSearchError(null);
    setBookingMessage(null);
    setBookingSuccess(null);
    setLoading(true);
    setSearched(true);
    setRecentSearches(previous => {
      const label = `${from} to ${to}${date ? ` on ${date}` : ''}`;
      return [label, ...previous.filter(item => item !== label)].slice(0, 4);
    });
    void trackGrowthEvent({
      userId: user?.id,
      eventName: 'ride_search_executed',
      funnelStage: 'searched',
      serviceType: 'ride',
      from,
      to,
      metadata: { date: date || null },
    });
  };

  const handleOpenRide = useCallback((ride: Ride) => {
    const rideSignal = resolveSignalForRoute(ride.from, ride.to);
    const priceQuote = getMovementPriceQuote({
      basePriceJod: ride.pricePerSeat,
      corridorId: rideSignal?.id,
      forecastDemandScore: rideSignal?.forecastDemandScore,
      membership: routeIntelligence.membership,
    });
    setSelected(ride);
    void trackGrowthEvent({
      userId: user?.id,
      eventName: 'ride_match_opened',
      funnelStage: 'selected',
      serviceType: 'ride',
      from: ride.from,
      to: ride.to,
      valueJod: priceQuote.finalPriceJod,
      metadata: {
        rideId: ride.id,
        driverName: ride.driver.name,
      },
    });
  }, [routeIntelligence.membership, user?.id]);

  const handleBook = useCallback(async (ride: Ride) => {
    if (bookingInFlightId) return;
    const existingBooking = bookingByRideId.get(ride.id);
    if (existingBooking) {
      setBookingMessage(
        existingBooking.status === 'pending_driver'
          ? `${ride.from} to ${ride.to} is already waiting for driver confirmation in My Trips.`
          : `${ride.from} to ${ride.to} is already confirmed in My Trips.`,
      );
      openMyTrips();
      return;
    }

    if (!user) {
      nav('/app/auth');
      return;
    }
    if (ride.seatsAvailable <= 0) {
      setBookingMessage(`That ride is full. ${t.openBusFallback}.`);
      setSelected(null);
      return;
    }

    const rideSignal = resolveSignalForRoute(ride.from, ride.to);
    const ridePriceQuote = getMovementPriceQuote({
      basePriceJod: ride.pricePerSeat,
      corridorId: rideSignal?.id,
      forecastDemandScore: rideSignal?.forecastDemandScore,
      membership: routeIntelligence.membership,
    });
    const finalPrice = ridePriceQuote.finalPriceJod;

    setBookingInFlightId(ride.id);

    try {
      const booking = await createRideBooking({
        rideId: ride.id,
        ownerId: ride.ownerId,
        passengerId: user.id,
        from: ride.from,
        to: ride.to,
        date: ride.date,
        time: ride.time,
        driverName: ride.driver.name,
        passengerName: user.name,
        seatsRequested: 1,
        pricePerSeatJod: finalPrice,
        routeMode: ride.routeMode === 'live_post' ? 'live_post' : 'network_inventory',
      });

      setRideBookings(getRideBookings());
      setSelected(null);
      setBookingSuccess({
        status: booking.status === 'pending_driver' ? 'pending_driver' : 'confirmed',
        routeLabel: `${ride.from} to ${ride.to}`,
        driverName: ride.driver.name,
        priceJod: finalPrice,
        ticketCode: booking.ticketCode,
      });
      setBookingMessage(
        booking.status === 'pending_driver'
          ? `Request sent for ${ride.from} to ${ride.to}.`
          : `Seat confirmed for ${ride.from} to ${ride.to}.`,
      );

      if (booking.status === 'confirmed') {
        try {
          await walletApi.pay(user.id, finalPrice, 'ride_booking', booking.id, {
            rideId: ride.id,
            from: ride.from,
            to: ride.to,
            seats: 1,
          });
        } catch (paymentError) {
          console.error('[Wallet] ride booking payment failed, cancelling booking:', paymentError);
          await updateRideBooking(booking.id, { status: 'cancelled' }).catch(() => {});
          setRideBookings(getRideBookings());
          setBookingSuccess(null);
          setBookingMessage(
            `Booking for ${ride.from} to ${ride.to} was cancelled because payment could not be processed. Please check your wallet balance and try again.`,
          );
          return;
        }
      } else {
        walletApi
          .pay(user.id, finalPrice, 'ride_booking', booking.id, {
            rideId: ride.id,
            from: ride.from,
            to: ride.to,
            seats: 1,
          })
          .catch(err => {
            console.warn('[Wallet] deferred payment queued for driver-confirm flow:', err);
          });
      }

      notificationsAPI
        .createNotification({
          title: booking.status === 'pending_driver' ? 'Route request sent' : t.bookingStarted,
          message:
            booking.status === 'pending_driver'
              ? `${ride.from} to ${ride.to} is waiting for driver approval at ${finalPrice} JOD.`
              : `${ride.from} to ${ride.to} at ${ride.time} is now in your trips at ${finalPrice} JOD with boarding reminders.`,
          type: 'booking',
          priority: 'high',
          action_url: '/app/my-trips?tab=rides',
        })
        .catch(() => {});

      if (permission === 'default') {
        requestPermission().catch(() => {});
      }

      notifyTripConfirmed(ride.driver.name, `${ride.from} to ${ride.to}`);
      void recordMovementActivity('ride_booked', corridorPlan?.id ?? null);
    } catch (error) {
      setSelected(null);
      setBookingSuccess(null);
      const message = error instanceof Error ? error.message : 'Unknown error';
      setBookingMessage(
        `Could not complete booking for ${ride.from} to ${ride.to}. ${message}. Please check your connection and try again.`,
      );
      console.error('[FindRide] Booking failed:', error);
    } finally {
      setBookingInFlightId(null);
    }
  }, [bookingInFlightId, bookingByRideId, nav, openMyTrips, t, user, routeIntelligence.membership, corridorPlan, permission, requestPermission, notifyTripConfirmed]);

  const handleDemandCapture = () => {
    const alert = createDemandAlert({
      from,
      to,
      date: date || new Date().toISOString().slice(0, 10),
      service: 'ride',
      userId: user?.id,
    });

    setWaitlistMessage(`Alert saved for ${alert.from} to ${alert.to}.`);
    void trackGrowthEvent({
      userId: user?.id,
      eventName: 'route_demand_alert_saved',
      funnelStage: 'searched',
      serviceType: 'ride',
      from: alert.from,
      to: alert.to,
    });
  };

  const handleSaveReminder = (corridorId: string) => {
    const suggestion = recurringSuggestions.find(item => item.corridorId === corridorId);
    if (!suggestion) return;

    const reminder = createReminderFromSuggestion(suggestion);
    setSavedReminders(getRouteReminders());
    setRetentionMessage(`Reminder saved. ${formatRouteReminderSchedule(reminder)}.`);
    void trackGrowthEvent({
      userId: user?.id,
      eventName: 'route_reminder_saved',
      funnelStage: 'selected',
      serviceType: 'ride',
      from: reminder.from,
      to: reminder.to,
    });
  };

  return (
    <Protected>
      <PageShell>
        <SectionHead
          emoji={<Search size={24} />}
          title="Book a Ride"
          titleAr="احجز مشوار"
          sub="Compare verified routes, live demand, and route-level price clarity."
          action={{ label: 'Offer a ride', onClick: () => nav('/app/offer-ride') }}
        />

        {/* Persistent booking indicator */}
        {bookedRideIds.size > 0 && (
          <div
            style={{
              marginBottom: 16,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              gap: 12,
              background: `${DS.green}12`,
              border: `1px solid ${DS.green}30`,
              borderRadius: r(14),
              padding: '12px 16px',
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <CheckCircle2 size={16} color={DS.green} />
              <span style={{ color: C.text, fontSize: '0.84rem', fontWeight: 700 }}>
                {bookedRideIds.size} active booking{bookedRideIds.size > 1 ? 's' : ''} in progress
              </span>
            </div>
            <WaselButton onClick={openMyTrips} variant="outline" size="sm">
              View in My Trips
            </WaselButton>
          </div>
        )}

        <div style={{ display: 'flex', gap: 8, marginBottom: 24 }}>
          {(
            [
              ['ride', 'Shared route'],
              ['package', copy.tabPackage],
            ] as const
          ).map(([key, label]) => (
            <WaselButton
              key={key}
              onClick={() => setTab(key)}
              variant={tab === key ? 'primary' : 'outline'}
              style={{
                flex: 1,
              }}
            >
              {label}
            </WaselButton>
          ))}
        </div>

        {tab === 'ride' && (
          <>
            <div
              style={{
                background: DS.card,
                borderRadius: r(16),
                padding: 20,
                border: `1px solid ${DS.border}`,
                marginBottom: 22,
              }}
            >
              <div
                className="sp-search-grid"
                style={{
                  display: 'grid',
                  gridTemplateColumns: '1fr 1fr 180px',
                  gap: 12,
                  marginBottom: 14,
                }}
              >
                {[
                  { label: t.from, value: from, setter: setFrom, icon: DS.green },
                  { label: t.to, value: to, setter: setTo, icon: DS.cyan },
                ].map(field => (
                  <div key={field.label}>
                    <label
                      style={{
                        display: 'block',
                        fontSize: '0.7rem',
                        color: DS.muted,
                        fontWeight: 700,
                        marginBottom: 6,
                      }}
                    >
                      {field.label}
                    </label>
                    <WaselSelect
                      value={field.value}
                      onChange={field.setter}
                      options={CITIES.map(city => ({ value: city, label: city }))}
                      containerStyle={{ gap: 0 }}
                      style={{ height: 46, paddingLeft: 42 }}
                    />
                  </div>
                ))}
                <div>
                  <label
                    style={{
                      display: 'block',
                      fontSize: '0.7rem',
                      color: DS.muted,
                      fontWeight: 700,
                      marginBottom: 6,
                    }}
                  >
                    {t.date}
                  </label>
                  <WaselInput
                    type="date"
                    value={date}
                    onChange={setDate}
                    min={new Date().toISOString().split('T')[0]}
                    icon={<Calendar size={15} color={DS.muted} />}
                    style={{ height: 46, colorScheme: 'dark' }}
                  />
                </div>
              </div>

              {searchError && (
                <div
                  style={{
                    marginBottom: 14,
                    display: 'flex',
                    gap: 10,
                    alignItems: 'center',
                    background: `${DS.gold}12`,
                    border: `1px solid ${DS.gold}30`,
                    borderRadius: r(14),
                    padding: '12px 14px',
                    color: C.text,
                    fontSize: '0.84rem',
                  }}
                >
                  <Shield size={16} color={DS.gold} />
                  <span>{searchError}</span>
                </div>
              )}

              <WaselButton
                onClick={handleSearch}
                data-testid="find-ride-search"
                fullWidth
                size="lg"
                style={{
                  gap: 10,
                }}
              >
                {loading || inventoryLoading ? (
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ duration: 0.8, repeat: Infinity, ease: 'linear' }}
                    style={{
                      width: 20,
                      height: 20,
                      border: `2px solid ${C.border}`,
                      borderTop: `2px solid ${C.text}`,
                      borderRadius: '50%',
                    }}
                  />
                ) : (
                  <Search size={18} />
                )}
                {loading || inventoryLoading ? t.searching : 'Search rides'}
              </WaselButton>

              <div
                style={{
                  marginTop: 14,
                  background: DS.card2,
                  borderRadius: r(14),
                  padding: 12,
                  border: `1px solid ${DS.border}`,
                }}
              >
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    gap: 12,
                    marginBottom: 10,
                    flexWrap: 'wrap',
                  }}
                >
                  <div>
                    <p
                      style={{
                        color: DS.muted,
                        fontSize: '0.72rem',
                        fontWeight: 700,
                        margin: '0 0 4px',
                      }}
                    >
                      Route preview
                    </p>
                    <p style={{ color: DS.sub, fontSize: '0.8rem', margin: 0 }}>
                      {selectedSignal
                        ? `${selectedSignal.liveSearches} people searching · ${selectedSignal.liveBookings} booked · ${selectedSignal.activeDemandAlerts} watching`
                        : 'Select a route above to see live demand.'}
                    </p>
                  </div>
                  {selectedSignal && (
                    <span style={{ ...pill(DS.green), fontSize: '0.72rem' }}>
                      {selectedSignal.forecastDemandScore}/100 demand score
                    </span>
                  )}
                </div>
                <MapWrapper
                  mode="static"
                  center={midpoint(searchFromCoord, searchToCoord)}
                  pickupLocation={searchFromCoord}
                  dropoffLocation={searchToCoord}
                  height={180}
                  showMosques={false}
                  showRadars={false}
                />
              </div>

              {bookingMessage && (
                <div
                  role="status"
                  aria-live="polite"
                  style={{
                    marginTop: 14,
                    display: 'flex',
                    gap: 10,
                    alignItems: 'center',
                    background: C.greenDim,
                    border: `1px solid ${C.greenDim}`,
                    borderRadius: r(14),
                    padding: '12px 14px',
                    color: C.text,
                    fontSize: '0.84rem',
                  }}
                >
                  <CheckCircle2 size={16} color={DS.green} />
                  <span>{bookingMessage}</span>
                </div>
              )}
              {bookingSuccess && (
                <div
                  style={{
                    marginTop: 14,
                    background: `linear-gradient(135deg, ${C.greenDim}, ${C.cyanDim})`,
                    border: `1px solid ${C.greenDim}`,
                    borderRadius: r(16),
                    padding: '16px 18px',
                    display: 'grid',
                    gap: 12,
                  }}
                >
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'flex-start',
                      justifyContent: 'space-between',
                      gap: 12,
                      flexWrap: 'wrap',
                    }}
                  >
                    <div>
                      <div style={{ color: C.text, fontWeight: 800, fontSize: '0.95rem' }}>
                        {bookingSuccess.status === 'pending_driver'
                          ? 'Request sent'
                          : 'Seat confirmed'}
                      </div>
                      <div
                        style={{ color: DS.sub, fontSize: '0.8rem', lineHeight: 1.6, marginTop: 6 }}
                      >
                        {bookingSuccess.status === 'pending_driver'
                          ? `${bookingSuccess.routeLabel} is now waiting on ${bookingSuccess.driverName}. Wasel will update My Trips as soon as the driver confirms.`
                          : `${bookingSuccess.routeLabel} is secured at ${bookingSuccess.priceJod} JOD. Boarding details and ticket tracking are now ready in My Trips.`}
                      </div>
                    </div>
                    <span
                      style={{
                        ...pill(bookingSuccess.status === 'pending_driver' ? DS.gold : DS.green),
                        fontSize: '0.72rem',
                      }}
                    >
                      {bookingSuccess.status === 'pending_driver'
                        ? `${bookingSuccess.priceJod} JOD pending`
                        : `${bookingSuccess.priceJod} JOD confirmed`}
                    </span>
                  </div>
                  <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
                    <WaselButton onClick={openMyTrips} variant="gold" size="sm">
                      Open My Trips
                    </WaselButton>
                    <WaselButton
                      onClick={() => setBookingSuccess(null)}
                      variant="outline"
                      size="sm"
                    >
                      Keep browsing
                    </WaselButton>
                  </div>
                  {bookingSuccess.ticketCode ? (
                    <div style={{ color: DS.muted, fontSize: '0.74rem' }}>
                      Ticket {bookingSuccess.ticketCode}
                    </div>
                  ) : null}
                </div>
              )}
              {retentionMessage && (
                <div
                  style={{
                    marginTop: 14,
                    display: 'flex',
                    gap: 10,
                    alignItems: 'center',
                    background: `${DS.cyan}12`,
                    border: `1px solid ${DS.cyan}30`,
                    borderRadius: r(14),
                    padding: '12px 14px',
                    color: C.text,
                    fontSize: '0.84rem',
                  }}
                >
                  <Sparkles size={16} color={DS.cyan} />
                  <span>{retentionMessage}</span>
                </div>
              )}

              <div
                className="sp-4col"
                style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(2, minmax(0, 1fr))',
                  gap: 12,
                  marginTop: 14,
                }}
              >
                {[
                  {
                    label: 'Available departures',
                    value: selectedSignal
                      ? `${selectedSignal.activeSupply} departures`
                      : `${corridorRides.length} departures`,
                    sub: selectedSignal
                      ? `${selectedSignal.liveBookings} booked · ${selectedSignal.activeDemandAlerts} watching`
                      : 'Live supply on this route',
                    tone: DS.cyan,
                  },
                  {
                    label: 'Shared seat price',
                    value: selectedPriceQuote ? `${selectedPriceQuote.finalPriceJod} JOD` : '--',
                    sub: selectedPriceQuote
                      ? `You save ${selectedPriceQuote.discountJod} JOD vs solo`
                      : 'Price shown after search',
                    tone: DS.green,
                  },
                  {
                    label: 'Next departure window',
                    value:
                      selectedSignal?.nextWaveWindow ??
                      corridorPlan?.autoGroupWindow ??
                      'Check after search',
                    sub:
                      selectedSignal?.recommendedPickupPoint ??
                      corridorPlan?.pickupPoints[0] ??
                      'Pickup point shown here',
                    tone: DS.gold,
                  },
                  {
                    label: 'Route reliability',
                    value: selectedSignal
                      ? `${selectedSignal.routeOwnershipScore}/100`
                      : (corridorPlan?.routeMoat ?? 'Growing'),
                    sub: selectedSignal
                      ? selectedSignal.productionSources.slice(0, 2).join(' · ')
                      : `${demandStats.active} saved alerts`,
                    tone: DS.cyan,
                  },
                ].map(item => (
                  <div
                    key={item.label}
                    style={{
                      background: DS.card2,
                      borderRadius: r(14),
                      padding: '14px 15px',
                      border: `1px solid ${DS.border}`,
                    }}
                  >
                    <div
                      style={{
                        color: DS.muted,
                        fontSize: '0.68rem',
                        fontWeight: 800,
                        marginBottom: 6,
                        textTransform: 'uppercase',
                        letterSpacing: 0,
                      }}
                    >
                      {item.label}
                    </div>
                    <div
                      style={{
                        color: item.tone,
                        fontWeight: 800,
                        fontSize: '0.88rem',
                        lineHeight: 1.55,
                      }}
                    >
                      {item.value}
                    </div>
                    <div
                      style={{ color: DS.sub, fontSize: '0.76rem', marginTop: 6, lineHeight: 1.55 }}
                    >
                      {item.sub}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div
              className="sp-results-header"
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                marginBottom: 16,
                flexWrap: 'wrap',
                gap: 10,
              }}
            >
              <h2 style={{ color: C.text, fontWeight: 800, fontSize: '0.95rem', margin: 0 }}>
                {searched
                  ? `${from} → ${to} · ${results.length} ride${results.length !== 1 ? 's' : ''} found`
                  : `Popular routes · ${results.length} departures`}
              </h2>
              {selectedSignal ? (
                <div style={{ color: DS.muted, fontSize: '0.74rem' }}>
                  Best price {selectedSignal.priceQuote.finalPriceJod} JOD · Next departure {selectedSignal.nextWaveWindow}
                </div>
              ) : null}
              <div className="sp-sort-bar" style={{ display: 'flex', gap: 6 }}>
                {(
                  [
                    ['price', t.cheapest],
                    ['time', t.earliest],
                    ['rating', t.topRated],
                  ] as const
                ).map(([key, label]) => (
                  <WaselButton
                    key={key}
                    onClick={() => setSort(key)}
                    variant={sort === key ? 'primary' : 'outline'}
                    size="sm"
                  >
                    {label}
                  </WaselButton>
                ))}
              </div>
            </div>

            <div className="sp-results-list" style={{ display: 'flex', flexDirection: 'column', gap: 14, marginBottom: 18 }}>
              <AnimatePresence>
                {results.length === 0 ? (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    style={{
                      background: DS.card,
                      borderRadius: r(20),
                      padding: '60px 24px',
                      textAlign: 'center',
                      border: `1px solid ${DS.border}`,
                    }}
                  >
                    <div style={{ fontSize: '3rem', marginBottom: 16 }}>{copy.noResultsIcon}</div>
                    <h3 style={{ color: C.text, fontWeight: 800, marginBottom: 8 }}>
                      {t.noRidesFound}
                    </h3>
                    <p style={{ color: DS.sub, fontSize: '0.875rem' }}>
                      No ride found yet. Save this route and get alerted when one opens
                      {selectedSignal ? ` around ${selectedSignal.nextWaveWindow}` : ''}.
                    </p>
                    <div
                      className="sp-empty-actions"
                      style={{
                        display: 'grid',
                        gridTemplateColumns: '1fr 1fr',
                        gap: 10,
                        marginTop: 18,
                      }}
                    >
                      <WaselButton
                        onClick={() => {
                          setDate('');
                          setSearchError(null);
                          setSearched(true);
                        }}
                        variant="outline"
                      >
                        {t.clearDateFilter}
                      </WaselButton>
                      <WaselButton
                        onClick={() =>
                          nav(
                            `/app/bus?from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}`,
                          )
                        }
                        variant="gold"
                      >
                        {t.openBusFallback}
                      </WaselButton>
                    </div>
                    <WaselButton
                      onClick={handleDemandCapture}
                      fullWidth
                      variant="outline"
                      style={{
                        marginTop: 10,
                      }}
                    >
                      {copy.notifyMe}
                    </WaselButton>
                    {(waitlistMessage || demandStats.active > 0) && (
                      <div
                        style={{
                          marginTop: 12,
                          color: DS.sub,
                          fontSize: '0.78rem',
                          lineHeight: 1.5,
                        }}
                      >
                        {waitlistMessage ??
                          `${demandStats.active} active alert${demandStats.active === 1 ? '' : 's'}.`}
                      </div>
                    )}
                    {nearbyCorridors.length > 0 && (
                      <div style={{ marginTop: 20, textAlign: 'left' }}>
                        <div style={{ color: C.text, fontWeight: 800, marginBottom: 10 }}>
                          {t.nearbyCorridors}
                        </div>
                        <div style={{ display: 'grid', gap: 10 }}>
                          {nearbyCorridors.map(ride => (
                            <WaselButton
                              key={ride.id}
                              onClick={() => handleOpenRide(ride)}
                              variant="outline"
                              style={{
                                textAlign: 'left',
                                padding: '12px 14px',
                                height: 'auto',
                                justifyContent: 'stretch',
                              }}
                            >
                              <div
                                style={{
                                  display: 'flex',
                                  alignItems: 'center',
                                  justifyContent: 'space-between',
                                  gap: 12,
                                  flexWrap: 'wrap',
                                }}
                              >
                                <div>
                                  <div
                                    style={{ color: C.text, fontWeight: 700, fontSize: '0.84rem' }}
                                  >
                                    {ride.from} to {ride.to}
                                  </div>
                                  <div
                                    style={{ color: DS.muted, fontSize: '0.74rem', marginTop: 4 }}
                                  >
                                    {ride.time} | {ride.driver.name}
                                  </div>
                                </div>
                                <span
                                  style={{ ...pill(ride.seatsAvailable > 0 ? DS.cyan : DS.gold) }}
                                >
                                  {ride.seatsAvailable > 0
                                    ? `${getMovementPriceQuote({ basePriceJod: ride.pricePerSeat, corridorId: resolveSignalForRoute(ride.from, ride.to)?.id, forecastDemandScore: resolveSignalForRoute(ride.from, ride.to)?.forecastDemandScore, membership: routeIntelligence.membership }).finalPriceJod} JOD`
                                    : 'Sold out'}
                                </span>
                              </div>
                            </WaselButton>
                          ))}
                        </div>
                      </div>
                    )}
                  </motion.div>
                ) : (
                  results.map((ride, index) => (
                    <FindRideCard
                      key={ride.id}
                      ride={ride}
                      idx={index}
                      bookingStatus={getRideBookingStatus(ride.id)}
                      signal={resolveSignalForRoute(ride.from, ride.to)}
                      onOpen={() => handleOpenRide(ride)}
                      onOpenBooking={openMyTrips}
                    />
                  ))
                )}
              </AnimatePresence>
            </div>

            <div
              className="sp-2col"
              style={{
                display: 'grid',
                gridTemplateColumns: '1.15fr 0.85fr',
                gap: 14,
                marginBottom: 18,
              }}
            >
              <div
                style={{
                  background: DS.card,
                  borderRadius: r(18),
                  padding: '18px 18px 16px',
                  border: `1px solid ${DS.border}`,
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
                  <div
                    style={{
                      width: 38,
                      height: 38,
                      borderRadius: r(12),
                      background: `${DS.cyan}12`,
                      border: `1px solid ${DS.cyan}28`,
                      display: 'grid',
                      placeItems: 'center',
                    }}
                  >
                    <Brain size={18} color={DS.cyan} />
                  </div>
                  <div>
                    <div style={{ color: C.text, fontWeight: 800 }}>Why this route fits</div>
                    <div style={{ color: DS.muted, fontSize: '0.76rem', marginTop: 2 }}>
                      Demand signals for {from} → {to}.
                    </div>
                  </div>
                </div>
                <div style={{ display: 'grid', gap: 10 }}>
                  {(selectedSignal
                    ? [
                      selectedSignal.recommendedReason,
                      `Next wave: ${selectedSignal.nextWaveWindow} from ${selectedSignal.recommendedPickupPoint}.`,
                      `Live feed: ${selectedSignal.productionSources.slice(0, 3).join(' | ')}.`,
                    ]
                    : (corridorPlan?.intelligenceSignals ?? [
                      'Demand builds before departure.',
                      'Pickup points stay simple.',
                      'Shared rides stay cheaper.',
                    ])
                  ).map(line => (
                    <div
                      key={line}
                      style={{
                        borderRadius: r(14),
                        border: `1px solid ${DS.border}`,
                        background: DS.card2,
                        padding: '12px 14px',
                        color: C.text,
                        fontSize: '0.82rem',
                        lineHeight: 1.65,
                      }}
                    >
                      {line}
                    </div>
                  ))}
                </div>
                <div style={{ marginTop: 12, display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                  {(corridorPlan?.movementLayers ?? ['people', 'goods', 'services']).map(layer => (
                    <span key={layer} style={pill(DS.green)}>
                      <Sparkles size={10} /> {layer}
                    </span>
                  ))}
                </div>
              </div>

              <div style={{ display: 'grid', gap: 14 }}>
                <div
                  style={{
                    background: DS.card,
                    borderRadius: r(18),
                    padding: '18px 18px 16px',
                    border: `1px solid ${DS.border}`,
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
                    <div
                      style={{
                        width: 38,
                        height: 38,
                        borderRadius: r(12),
                        background: `${DS.gold}12`,
                        border: `1px solid ${DS.gold}28`,
                        display: 'grid',
                        placeItems: 'center',
                      }}
                    >
                      <TrendingUp size={18} color={DS.gold} />
                    </div>
                    <div>
                      <div style={{ color: C.text, fontWeight: 800 }}>Popular routes right now</div>
                      <div style={{ color: DS.muted, fontSize: '0.76rem', marginTop: 2 }}>
                        Routes with strong live activity.
                      </div>
                    </div>
                  </div>
                  <div style={{ display: 'grid', gap: 10 }}>
                    {featuredSignals.map(corridor => (
                      <WaselButton
                        key={corridor.id}
                        onClick={() => {
                          setFrom(corridor.from);
                          setTo(corridor.to);
                          setSearched(true);
                        }}
                        variant="outline"
                        style={{
                          textAlign: 'left',
                          padding: '12px 14px',
                          height: 'auto',
                          justifyContent: 'stretch',
                        }}
                      >
                        <div
                          style={{
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'space-between',
                            gap: 12,
                            flexWrap: 'wrap',
                          }}
                        >
                          <div>
                            <div style={{ color: C.text, fontWeight: 700, fontSize: '0.84rem' }}>
                              {corridor.label}
                            </div>
                            <div style={{ color: DS.muted, fontSize: '0.74rem', marginTop: 4 }}>
                              Demand {corridor.forecastDemandScore} |{' '}
                              {corridor.priceQuote.finalPriceJod} JOD | Owns{' '}
                              {corridor.routeOwnershipScore}
                            </div>
                          </div>
                          <span style={pill(DS.cyan)}>{corridor.pricePressure}</span>
                        </div>
                      </WaselButton>
                    ))}
                  </div>
                </div>

                <div
                  style={{
                    background: DS.card,
                    borderRadius: r(18),
                    padding: '18px 18px 16px',
                    border: `1px solid ${DS.border}`,
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
                    <div
                      style={{
                        width: 38,
                        height: 38,
                        borderRadius: r(12),
                        background: `${DS.green}12`,
                        border: `1px solid ${DS.green}28`,
                        display: 'grid',
                        placeItems: 'center',
                      }}
                    >
                      <Network size={18} color={DS.green} />
                    </div>
                    <div>
                      <div style={{ color: C.text, fontWeight: 800 }}>Rides that also carry packages</div>
                      <div style={{ color: DS.muted, fontSize: '0.76rem', marginTop: 2 }}>
                        Some rides accept parcels on the same route.
                      </div>
                    </div>
                  </div>
                  <div style={{ display: 'grid', gap: 10 }}>
                    {marketplaceNodes.map(node => (
                      <div
                        key={node.id}
                        style={{
                          borderRadius: r(14),
                          border: `1px solid ${DS.border}`,
                          background: DS.card2,
                          padding: '12px 14px',
                        }}
                      >
                        <div style={{ color: C.text, fontWeight: 700, fontSize: '0.82rem' }}>
                          {node.title}
                        </div>
                        <div
                          style={{
                            color: DS.muted,
                            fontSize: '0.74rem',
                            marginTop: 4,
                            lineHeight: 1.55,
                          }}
                        >
                          {node.summary}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <div
              className="sp-2col"
              style={{
                display: 'grid',
                gridTemplateColumns: '1.15fr 0.85fr',
                gap: 14,
                marginBottom: 18,
              }}
            >
              <div
                style={{
                  background: DS.card,
                  borderRadius: r(18),
                  padding: '18px 18px 16px',
                  border: `1px solid ${DS.border}`,
                }}
              >
                <div style={{ color: C.text, fontWeight: 800, marginBottom: 12 }}>
                  Suggested reminders
                </div>
                {recurringSuggestions.length > 0 ? (
                  <div style={{ display: 'grid', gap: 10 }}>
                    {recurringSuggestions.map(suggestion => {
                      const alreadySaved = Boolean(
                        getRouteReminderForCorridor(suggestion.corridorId),
                      );
                      return (
                        <div
                          key={suggestion.corridorId}
                          style={{
                            borderRadius: r(14),
                            border: `1px solid ${DS.border}`,
                            background: DS.card2,
                            padding: '12px 14px',
                          }}
                        >
                          <div
                            style={{
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'space-between',
                              gap: 12,
                              flexWrap: 'wrap',
                            }}
                          >
                            <div>
                              <div style={{ color: C.text, fontWeight: 700, fontSize: '0.84rem' }}>
                                {suggestion.label}
                              </div>
                              <div style={{ color: DS.muted, fontSize: '0.74rem', marginTop: 4 }}>
                                {suggestion.confidenceScore}/100 |{' '}
                                {suggestion.priceQuote.finalPriceJod} JOD |{' '}
                                {suggestion.weeklyFrequency} signals
                              </div>
                            </div>
                            <span style={pill(DS.green)}>{suggestion.recommendedFrequency}</span>
                          </div>
                          <div
                            style={{
                              color: DS.sub,
                              fontSize: '0.76rem',
                              lineHeight: 1.55,
                              marginTop: 8,
                            }}
                          >
                            {suggestion.reason}
                          </div>
                          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginTop: 10 }}>
                            <WaselButton
                              onClick={() => {
                                setFrom(suggestion.from);
                                setTo(suggestion.to);
                                setSearched(true);
                              }}
                              variant="outline"
                              size="sm"
                            >
                              Search route
                            </WaselButton>
                            <WaselButton
                              onClick={() => handleSaveReminder(suggestion.corridorId)}
                              variant={alreadySaved ? 'gold' : 'primary'}
                              size="sm"
                            >
                              {alreadySaved ? 'Reminder active' : 'Save reminder'}
                            </WaselButton>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div style={{ color: DS.muted, fontSize: '0.8rem' }}>
                    Book more rides to unlock reminders.
                  </div>
                )}
              </div>

              <div
                style={{
                  background: DS.card,
                  borderRadius: r(18),
                  padding: '18px 18px 16px',
                  border: `1px solid ${DS.border}`,
                }}
              >
                <div style={{ color: C.text, fontWeight: 800, marginBottom: 12 }}>
                  Saved reminders
                </div>
                {savedReminders.length > 0 ? (
                  <div style={{ display: 'grid', gap: 10 }}>
                    {savedReminders.slice(0, 4).map(reminder => (
                      <div
                        key={reminder.id}
                        style={{
                          borderRadius: r(12),
                          border: `1px solid ${DS.border}`,
                          background: DS.card2,
                          padding: '11px 12px',
                        }}
                      >
                        <div style={{ color: C.text, fontWeight: 700, fontSize: '0.8rem' }}>
                          {reminder.label}
                        </div>
                        <div style={{ color: DS.muted, fontSize: '0.73rem', marginTop: 4 }}>
                          {formatRouteReminderSchedule(reminder)}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div style={{ color: DS.muted, fontSize: '0.8rem', lineHeight: 1.55 }}>
                    Save a route to see reminders here.
                  </div>
                )}
              </div>
            </div>

            <div
              className="sp-2col"
              style={{
                display: 'grid',
                gridTemplateColumns: '1.15fr 0.85fr',
                gap: 14,
                marginBottom: 18,
              }}
            >
              <div
                style={{
                  background: DS.card,
                  borderRadius: r(18),
                  padding: '18px 18px 16px',
                  border: `1px solid ${DS.border}`,
                }}
              >
                <div style={{ color: C.text, fontWeight: 800, marginBottom: 12 }}>
                  Best ride matches
                </div>
                <div style={{ display: 'grid', gap: 10 }}>
                  {recommendedRides.map(ride => {
                    const rideSignal = resolveSignalForRoute(ride.from, ride.to);
                    const ridePriceQuote = getMovementPriceQuote({
                      basePriceJod: ride.pricePerSeat,
                      corridorId: rideSignal?.id,
                      forecastDemandScore: rideSignal?.forecastDemandScore,
                      membership: routeIntelligence.membership,
                    });

                    return (
                      <WaselButton
                        key={ride.id}
                        onClick={() => handleOpenRide(ride)}
                        variant="outline"
                        style={{
                          textAlign: 'left',
                          padding: '12px 14px',
                          height: 'auto',
                          justifyContent: 'stretch',
                        }}
                      >
                        <div
                          style={{
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'space-between',
                            gap: 12,
                            flexWrap: 'wrap',
                          }}
                        >
                          <div>
                            <div style={{ color: C.text, fontWeight: 700, fontSize: '0.84rem' }}>
                              {ride.from} to {ride.to}
                            </div>
                            <div style={{ color: DS.muted, fontSize: '0.74rem', marginTop: 4 }}>
                              {ride.time} | {ride.driver.name} |{' '}
                              {rideSignal
                                ? `${rideSignal.routeOwnershipScore}/100 ownership`
                                : ride.car}
                            </div>
                          </div>
                          <span
                            style={{ ...pill(bookedRideIds.has(ride.id) ? DS.green : DS.cyan) }}
                          >
                            {bookedRideIds.has(ride.id)
                              ? 'Booked'
                              : `${ridePriceQuote.finalPriceJod} JOD`}
                          </span>
                        </div>
                      </WaselButton>
                    );
                  })}
                </div>
              </div>

              <div style={{ display: 'grid', gap: 14 }}>
                {[
                  { title: t.recentSearches, items: recentSearches, empty: t.searchHelp },
                  {
                    title: t.bookedTrips,
                    items: bookedRides.map(
                      ride => `${ride.from} to ${ride.to} | ${ride.time} | ${ride.driver.name}`,
                    ),
                    empty: t.noTripsYet,
                  },
                ].map(card => (
                  <div
                    key={card.title}
                    style={{
                      background: DS.card,
                      borderRadius: r(18),
                      padding: '18px 18px 16px',
                      border: `1px solid ${DS.border}`,
                    }}
                  >
                    <div style={{ color: C.text, fontWeight: 800, marginBottom: 12 }}>
                      {card.title}
                    </div>
                    {recentSearches.length > 0 ? (
                      <div style={{ display: 'grid', gap: 10 }}>
                        {recentSearches.map(item => (
                          <button
                            key={item}
                            onClick={() => {
                              const parts = item.split(' to ');
                              if (parts[0]) setFrom(parts[0]);
                              const toPart = parts[1]?.split(' on ')[0];
                              if (toPart) setTo(toPart);
                              setSearched(true);
                            }}
                            style={{
                              borderRadius: r(12),
                              border: `1px solid ${DS.border}`,
                              background: DS.card2,
                              padding: '11px 12px',
                              color: C.text,
                              fontSize: '0.78rem',
                              textAlign: 'left',
                              cursor: 'pointer',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'space-between',
                              gap: 8,
                            }}
                          >
                            <span>{item}</span>
                            <Search size={12} color={DS.muted} />
                          </button>
                        ))}
                      </div>
                    ) : (
                      <div style={{ color: DS.muted, fontSize: '0.8rem' }}>{t.searchHelp}</div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </>
        )}

        {tab === 'package' && (
          <FindRidePackagePanel ar={ar} copy={copy} t={t} pkg={pkg} setPkg={setPkg} />
        )}

        <ServiceFlowPlaybook focusService={tab === 'ride' ? 'find-ride' : 'send-package'} />

        {selected && (
          <FindRideTripDetailModal
            ride={selected}
            bookingStatus={
              selectedBooking &&
                (selectedBooking.status === 'pending_driver' ||
                  selectedBooking.status === 'confirmed')
                ? selectedBooking.status
                : null
            }
            signal={resolveSignalForRoute(selected.from, selected.to)}
            isBooking={bookingInFlightId === selected.id}
            onClose={() => setSelected(null)}
            onBook={() => handleBook(selected)}
            onOpenBooking={openMyTrips}
          />
        )}
      </PageShell>
    </Protected>
  );
}

export default FindRidePage;
