import { AnimatePresence, motion } from 'motion/react';
import { useEffect, useRef, type MouseEvent } from 'react';
import {
  Calendar,
  Car,
  CheckCircle2,
  ChevronRight,
  Clock,
  Navigation,
  Star,
  Users,
  X,
} from 'lucide-react';
import { MapWrapper } from '../../../components/MapWrapper';
import { WaselButton } from '../../../components/wasel-ui';
import { getCorridorOpportunity } from '../../../config/wasel-movement-network';
import { DS, midpoint, pill, r, resolveCityCoord } from '../../../pages/waselServiceShared';
import { getMovementPriceQuote } from '../../../services/movementPricing';
import type { LiveCorridorSignal } from '../../../services/routeDemandIntelligence';
import { createGenderMeta, type Ride } from '../../../pages/waselCoreRideData';
import { C, GRAD_HERO } from '../../../utils/wasel-ds';
import { getCurrentLang, tx } from '../../../locales/tx';

const GENDER_META = createGenderMeta(DS);
const CITY_LABELS_AR: Record<string, string> = {
  Amman: 'عمّان',
  Aqaba: 'العقبة',
  Irbid: 'إربد',
  Zarqa: 'الزرقاء',
  Salt: import.meta.env.VITE_FIND_RIDE_TRIP_SALT_LABEL || 'السلط',
  Madaba: 'مادبا',
  Jerash: 'جرش',
  Karak: 'الكرك',
  Mafraq: 'المفرق',
  Tafilah: 'الطفيلة',
  "Ma'an": 'معان',
  Ajloun: 'عجلون',
  'Dead Sea': 'البحر الميت',
  Petra: 'البتراء',
  'Wadi Rum': 'وادي رم',
};
const PICKUP_LABELS_AR: Record<string, string> = {
  '7th Circle launch point': 'نقطة الانطلاق عند الدوار السابع',
  'Abdali transfer gate': 'بوابة تبديل العبدلي',
  'Airport road merge': 'مدخل طريق المطار',
  'Aqaba logistics zone': 'منطقة العقبة اللوجستية',
  'North Amman ring': 'حلقة شمال عمّان',
  'Jerash gate': 'بوابة جرش',
  'festival shuttle node': 'نقطة نقل المهرجان',
  'South Amman edge': 'طرف جنوب عمّان',
  'Mujib connector': 'وصلة الموجب',
  'Karak city gate': 'بوابة مدينة الكرك',
};

function cityLabel(city: string) {
  return getCurrentLang() === 'ar' ? CITY_LABELS_AR[city] ?? city : city;
}

function localizeSignalText(value: string) {
  if (getCurrentLang() !== 'ar') return value;
  return value
    .replace(/\band\b/g, 'و')
    .replace(/live searches/g, 'عمليات بحث مباشرة')
    .replace(/live bookings/g, 'حجوزات مباشرة')
    .replace(/package moves/g, 'حركة طرود');
}

function pickupLabel(value: string) {
  return getCurrentLang() === 'ar' ? PICKUP_LABELS_AR[value] ?? localizeSignalText(value) : value;
}

type FindRideTripDetailModalProps = {
  ride: Ride;
  bookingStatus?: 'pending_driver' | 'confirmed' | null;
  signal?: LiveCorridorSignal | null;
  isBooking?: boolean;
  onClose: () => void;
  onBook: () => void;
  onOpenBooking: () => void;
};

function getConversationMeta(level: Ride['conversationLevel']) {
  const ar = getCurrentLang() === 'ar';
  switch (level) {
    case 'quiet':
      return { badge: ar ? 'هادئ' : 'Quiet', label: ar ? 'مشوار هادئ' : 'Quiet ride' };
    case 'talkative':
      return { badge: ar ? 'اجتماعي' : 'Social', label: ar ? 'محب للحكي' : 'Talkative' };
    default:
      return { badge: ar ? 'متوازن' : 'Balanced', label: ar ? 'طبيعي' : 'Normal' };
  }
}

export function FindRideTripDetailModal({
  ride,
  bookingStatus = null,
  signal = null,
  isBooking = false,
  onClose,
  onBook,
  onOpenBooking,
}: FindRideTripDetailModalProps) {
  const soldOut = ride.seatsAvailable <= 0;
  const hasBooking = bookingStatus === 'pending_driver' || bookingStatus === 'confirmed';
  const ar = getCurrentLang() === 'ar';
  const conversationMeta = getConversationMeta(ride.conversationLevel);
  const pickupCoord = resolveCityCoord(ride.from);
  const dropoffCoord = resolveCityCoord(ride.to);
  const driverCoord = midpoint(pickupCoord, dropoffCoord);
  const genderMeta = GENDER_META[ride.genderPref];
  const corridorPlan = getCorridorOpportunity(ride.from, ride.to);
  const priceQuote = getMovementPriceQuote({
    basePriceJod: ride.pricePerSeat,
    corridorId: signal?.id,
    forecastDemandScore: signal?.forecastDemandScore,
  });
  const dialogRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  useEffect(() => {
    const dialog = dialogRef.current;
    if (!dialog) return;
    const focusable = dialog.querySelectorAll<HTMLElement>(
      'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])',
    );
    const first = focusable[0];
    const last = focusable[focusable.length - 1];
    if (first) first.focus();

    const handleTab = (event: KeyboardEvent) => {
      if (event.key !== 'Tab') return;
      if (focusable.length === 0) return;
      if (event.shiftKey) {
        if (document.activeElement === first) {
          event.preventDefault();
          last?.focus();
        }
      } else {
        if (document.activeElement === last) {
          event.preventDefault();
          first?.focus();
        }
      }
    };
    dialog.addEventListener('keydown', handleTab);
    return () => dialog.removeEventListener('keydown', handleTab);
  }, [onClose]);

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        style={{
          position: 'fixed',
          inset: 0,
          background: C.overlay,
          backdropFilter: 'blur(6px)',
          zIndex: 2000,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          padding: 16,
          touchAction: 'pan-y',
        }}
      >
        <motion.div
          ref={dialogRef}
          initial={{ scale: 0.9, opacity: 0, y: 30 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.9, opacity: 0, y: 30 }}
          transition={{ type: 'spring', damping: 25, stiffness: 300 }}
          onClick={(event: MouseEvent) => event.stopPropagation()}
          style={{
            background: DS.card,
            border: `1px solid ${DS.border}`,
            borderRadius: r(24),
            width: '100%',
            maxWidth: 580,
            maxHeight: 'min(90dvh, 90vh)',
            overflowY: 'auto',
            WebkitOverflowScrolling: 'touch',
          }}
        >
          <div
            style={{
              background: GRAD_HERO,
              borderRadius: `${r(24)} ${r(24)} 0 0`,
              padding: '24px 28px',
              position: 'sticky',
              top: 0,
              zIndex: 10,
            }}
          >
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                marginBottom: 12,
              }}
            >
              <h2
                style={{
                  color: C.text,
                  fontWeight: 900,
                  fontSize: '1.2rem',
                  margin: 0,
                }}
              >
                {tx('trips.tripDetails')}</h2>
              <WaselButton
                onClick={onClose}
                variant="ghost"
                size="sm"
                aria-label={tx('findRideTripDetailModal.close_trip_details')}
                style={{
                  width: 36,
                  height: 36,
                  padding: 0,
                }}
              >
                <X size={18} />
              </WaselButton>
            </div>
            <div
              className="sp-modal-route"
              style={{ display: 'flex', alignItems: 'center', gap: 12 }}
            >
              <div style={{ textAlign: 'center' }}>
                <div style={{ fontWeight: 800, color: C.text, fontSize: '1.1rem' }}>
                  {cityLabel(ride.from)}
                </div>
                <div style={{ color: DS.cyan, fontSize: '0.75rem' }}>{ride.fromPoint}</div>
              </div>
              <div
                style={{
                  flex: 1,
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  gap: 4,
                }}
              >
                <div
                  style={{
                    width: '100%',
                    height: 2,
                    background: `linear-gradient(90deg,${DS.green},${DS.cyan})`,
                    borderRadius: 2,
                  }}
                />
                <span style={{ color: DS.sub, fontSize: '0.72rem' }}>
                  {ride.duration} | {ride.distance} {tx('findRideTripDetailModal.km')}</span>
              </div>
              <div style={{ textAlign: 'center' }}>
                <div style={{ fontWeight: 800, color: C.text, fontSize: '1.1rem' }}>{cityLabel(ride.to)}</div>
                <div style={{ color: DS.cyan, fontSize: '0.75rem' }}>{ride.toPoint}</div>
              </div>
            </div>
          </div>

          <div style={{ padding: '24px 28px', display: 'flex', flexDirection: 'column', gap: 20 }}>
            <div
              style={{
                background: DS.card2,
                borderRadius: r(16),
                padding: '18px 20px',
                border: `1px solid ${DS.border}`,
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                <div
                  style={{
                    width: 52,
                    height: 52,
                    borderRadius: r(14),
                    background: DS.gradC,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontWeight: 900,
                    color: C.text,
                    fontSize: '1.1rem',
                    flexShrink: 0,
                  }}
                >
                  {ride.driver.avatar}
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <span style={{ fontWeight: 800, color: C.text, fontSize: '1.05rem' }}>
                      {ride.driver.name}
                    </span>
                    {ride.driver.verified && (
                      <span style={{ ...pill(DS.green), fontSize: '0.6rem' }}>
                        <CheckCircle2 size={9} /> {tx('verification.verified')}</span>
                    )}
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 4 }}>
                    <Star size={13} fill={C.gold} color={C.gold} />
                    <span style={{ color: C.gold, fontWeight: 700, fontSize: '0.82rem' }}>
                      {ride.driver.rating}
                    </span>
                    <span style={{ color: DS.muted, fontSize: '0.75rem' }}>
                      | {ride.driver.trips} {tx('findRideTripDetailModal.trips')}</span>
                  </div>
                </div>
                <div style={{ display: 'flex', gap: 8 }}>
                  <a
                    href={`https://wa.me/${ride.driver.phone.replace(/[^0-9]/g, '')}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    style={{
                      width: 38,
                      height: 38,
                      borderRadius: r(10),
                      background: C.greenDim,
                      border: `1px solid ${C.greenDim}`,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      textDecoration: 'none',
                    }}
                  >
                    <svg width="16" height="16" viewBox="0 0 24 24" fill={C.green}>
                      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
                    </svg>
                  </a>
                </div>
              </div>
              <div
                style={{
                  marginTop: 12,
                  display: 'flex',
                  alignItems: 'center',
                  gap: 8,
                  padding: '10px 14px',
                  background: C.elevated,
                  borderRadius: r(10),
                }}
              >
                <Car size={14} color={DS.cyan} />
                <span style={{ color: C.text, fontWeight: 600, fontSize: '0.85rem' }}>
                  {ride.car}
                </span>
              </div>
            </div>

            <div
              className="sp-modal-metrics"
              style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}
            >
              {[
                { icon: <Calendar size={14} />, label: ar ? 'التاريخ' : 'Date', val: ride.date },
                { icon: <Clock size={14} />, label: ar ? 'المغادرة' : 'Departure', val: ride.time },
                {
                  icon: <Users size={14} />,
                  label: ar ? 'المقاعد المتبقية' : 'Seats left',
                  val: `${ride.seatsAvailable} / ${ride.totalSeats}`,
                },
                {
                  icon: <Navigation size={14} />,
                  label: signal ? (ar ? 'الطلب المباشر' : 'Live demand') : (ar ? 'المسافة' : 'Distance'),
                  val: signal ? `${signal.forecastDemandScore}/100` : `${ride.distance} ${ar ? 'كم' : 'km'}`,
                },
              ].map(item => (
                <div
                  key={item.label}
                  style={{
                    background: DS.card2,
                    borderRadius: r(12),
                    padding: '14px 16px',
                    border: `1px solid ${DS.border}`,
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 4 }}>
                    <span style={{ color: DS.cyan }}>{item.icon}</span>
                    <span style={{ color: DS.muted, fontSize: '0.7rem', fontWeight: 600 }}>
                      {item.label}
                    </span>
                  </div>
                  <div style={{ color: C.text, fontWeight: 700, fontSize: '0.9rem' }}>
                    {item.val}
                  </div>
                </div>
              ))}
            </div>

            {signal ? (
              <div
                style={{
                  background: DS.card2,
                  borderRadius: r(16),
                  padding: '16px 18px',
                  border: `1px solid ${DS.border}`,
                }}
              >
                <div style={{ color: C.text, fontWeight: 800, marginBottom: 10 }}>
                  {tx('findRideTripDetailModal.production_route_proof')}</div>
                <div style={{ display: 'grid', gap: 8 }}>
                  {[
                    ar
                      ? `درجة ملكية المسار: ${signal.routeOwnershipScore}/100.`
                      : `Route ownership score: ${signal.routeOwnershipScore}/100.`,
                    ar
                      ? `الموجة المقترحة القادمة: ${localizeSignalText(signal.nextWaveWindow)}. أفضل نقطة انطلاق هي ${pickupLabel(signal.recommendedPickupPoint)}.`
                      : `Next recommended wave: ${signal.nextWaveWindow}. Best pickup point is ${signal.recommendedPickupPoint}.`,
                    localizeSignalText(signal.productionSources.slice(0, 3).join(' | ')),
                  ].map(line => (
                    <div key={line} style={{ color: DS.sub, fontSize: '0.78rem', lineHeight: 1.6 }}>
                      {line}
                    </div>
                  ))}
                </div>
              </div>
            ) : null}

            <div
              style={{
                background: DS.card2,
                borderRadius: r(16),
                padding: '14px',
                border: `1px solid ${DS.border}`,
              }}
            >
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  gap: 12,
                  marginBottom: 10,
                  flexWrap: 'wrap',
                }}
              >
                <div>
                  <p
                    style={{
                      color: DS.muted,
                      fontSize: '0.72rem',
                      fontWeight: 700,
                      letterSpacing: 0,
                      textTransform: 'uppercase',
                      margin: '0 0 4px',
                    }}
                  >
                    {tx('findRideTripDetailModal.route_map')}</p>
                  <p style={{ color: DS.sub, fontSize: '0.8rem', margin: 0 }}>
                    {tx('findRideTripDetailModal.a_clear_preview_of_pickup_destination_and_route_direction')}</p>
                </div>
                <span style={{ ...pill(DS.cyan), fontSize: '0.72rem' }}>{tx('findRideTripDetailModal.friendly_map_preview')}</span>
              </div>
              <MapWrapper
                mode="live"
                center={midpoint(pickupCoord, dropoffCoord)}
                pickupLocation={pickupCoord}
                dropoffLocation={dropoffCoord}
                driverLocation={driverCoord}
                height={220}
                showMosques={false}
                showRadars={false}
              />
            </div>

            <div>
              <p
                style={{
                  color: DS.muted,
                  fontSize: '0.72rem',
                  fontWeight: 700,
                  letterSpacing: 0,
                  textTransform: 'uppercase',
                  marginBottom: 10,
                }}
              >
                {tx('services.luxury.amenities')}</p>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                {ride.amenities.map(amenity => (
                  <span
                    key={amenity}
                    style={{ ...pill(DS.cyan), padding: '5px 12px', fontSize: '0.75rem' }}
                  >
                    {amenity}
                  </span>
                ))}
                {ride.prayerStops && (
                  <span style={{ ...pill(DS.gold), padding: '5px 12px', fontSize: '0.75rem' }}>
                    {tx('findRideTripDetailModal.prayer_stops')}</span>
                )}
                {ride.ramadan && (
                  <span style={{ ...pill(C.purple), padding: '5px 12px', fontSize: '0.75rem' }}>
                    {tx('findRideTripDetailModal.ramadan_friendly')}</span>
                )}
                <span
                  style={{ ...pill(genderMeta.color), padding: '5px 12px', fontSize: '0.75rem' }}
                >
                  {genderMeta.emoji} {genderMeta.label}
                </span>
                <span style={{ ...pill(DS.sub), padding: '5px 12px', fontSize: '0.75rem' }}>
                  {conversationMeta.badge} {conversationMeta.label}
                </span>
              </div>
            </div>

            {ride.intermediateStops && ride.intermediateStops.length > 0 && (
              <div
                style={{
                  background: DS.card2,
                  borderRadius: r(12),
                  padding: '14px 18px',
                  border: `1px solid ${DS.border}`,
                }}
              >
                <p
                  style={{
                    color: DS.muted,
                    fontSize: '0.72rem',
                    fontWeight: 700,
                    letterSpacing: 0,
                    textTransform: 'uppercase',
                    marginBottom: 8,
                  }}
                >
                  {tx('findRideTripDetailModal.route_stops')}</p>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
                  <span style={{ color: C.text, fontWeight: 600, fontSize: '0.82rem' }}>
                    {cityLabel(ride.from)}
                  </span>
                  {ride.intermediateStops.map(stop => (
                    <span key={stop} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                      <ChevronRight size={12} color={DS.muted} />
                      <span style={{ color: DS.cyan, fontWeight: 600, fontSize: '0.82rem' }}>
                        {stop}
                      </span>
                    </span>
                  ))}
                  <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                    <ChevronRight size={12} color={DS.muted} />
                    <span style={{ color: C.text, fontWeight: 600, fontSize: '0.82rem' }}>
                      {cityLabel(ride.to)}
                    </span>
                  </span>
                </div>
              </div>
            )}

            {ride.reviews && ride.reviews.length > 0 && (
              <div>
                <p
                  style={{
                    color: DS.muted,
                    fontSize: '0.72rem',
                    fontWeight: 700,
                    letterSpacing: 0,
                    textTransform: 'uppercase',
                    marginBottom: 10,
                  }}
                >
                  {tx('findRideTripDetailModal.passenger_reviews')}</p>
                {ride.reviews.map((review, index) => (
                  <div
                    key={`${review.name}-${index}`}
                    style={{
                      background: DS.card2,
                      borderRadius: r(12),
                      padding: '14px 16px',
                      border: `1px solid ${DS.border}`,
                      marginBottom: 8,
                    }}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
                      <span style={{ fontWeight: 700, color: C.text, fontSize: '0.85rem' }}>
                        {review.name}
                      </span>
                      <div style={{ display: 'flex', gap: 2 }}>
                        {Array.from({ length: review.rating }).map((_, starIndex) => (
                          <Star key={starIndex} size={11} fill={C.gold} color={C.gold} />
                        ))}
                      </div>
                    </div>
                    <p style={{ color: DS.sub, fontSize: '0.8rem', margin: 0 }}>{review.text}</p>
                  </div>
                ))}
              </div>
            )}

            <div
              className="sp-modal-price"
              style={{
                background: GRAD_HERO,
                borderRadius: r(16),
                padding: '20px 24px',
                border: `1px solid ${DS.cyan}20`,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                gap: 14,
              }}
            >
              <div>
                <div style={{ color: DS.sub, fontSize: '0.75rem', marginBottom: 4 }}>
                  {tx('findRideTripDetailModal.price_per_seat')}</div>
                <div style={{ color: DS.cyan, fontWeight: 900, fontSize: '2rem' }}>
                  {priceQuote.finalPriceJod}{' '}
                  <span style={{ fontSize: '1rem', fontWeight: 600 }}>JOD</span>
                </div>
                <div style={{ color: DS.muted, fontSize: '0.72rem', marginTop: 2 }}>
                  {tx('findRideTripDetailModal.base')}{priceQuote.basePriceJod} {tx('findRideTripDetailModal.jod_save')}{priceQuote.discountJod} JOD
                </div>
                {corridorPlan && (
                  <div style={{ marginTop: 10, display: 'grid', gap: 6 }}>
                    <div style={{ color: DS.green, fontSize: '0.76rem', fontWeight: 800 }}>
                      {corridorPlan.savingsPercent}{tx('findRideTripDetailModal.cheaper_than_solo_movement')}</div>
                    <div style={{ color: DS.sub, fontSize: '0.72rem', lineHeight: 1.55 }}>
                      {tx('findRideTripDetailModal.solo_reference')}{corridorPlan.soloReferencePriceJod} {tx('findRideTripDetailModal.jod_best_pickup')}{' '}
                      {signal?.recommendedPickupPoint ?? corridorPlan.pickupPoints[0]}
                    </div>
                    <div style={{ color: DS.cyan, fontSize: '0.72rem', lineHeight: 1.55 }}>
                      {priceQuote.explanation}
                    </div>
                  </div>
                )}
              </div>
              <div
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  gap: 10,
                  alignItems: 'flex-end',
                  width: '100%',
                }}
              >
                <motion.button
                  whileHover={{ scale: 1.04 }}
                  whileTap={{ scale: 0.96 }}
                  onClick={hasBooking ? onOpenBooking : onBook}
                  disabled={soldOut || isBooking}
                  style={{
                    height: 50,
                    padding: '0 32px',
                    borderRadius: '99px',
                    border: 'none',
                    cursor: soldOut || isBooking ? 'not-allowed' : 'pointer',
                    background: hasBooking
                      ? bookingStatus === 'pending_driver'
                        ? DS.gradGold
                        : DS.gradG
                      : soldOut
                        ? C.elevated
                        : DS.gradC,
                    color: C.text,
                    fontWeight: 800,
                    fontSize: '0.95rem',
                    boxShadow: `0 8px 24px ${
                      hasBooking
                        ? bookingStatus === 'pending_driver'
                          ? DS.gold
                          : DS.green
                        : soldOut
                          ? C.border
                          : DS.cyan
                    }40`,
                    opacity: soldOut || isBooking ? 0.9 : 1,
                    width: '100%',
                  }}
                >
                  {hasBooking
                    ? ar ? 'افتح في رحلاتي' : 'Open in My Trips'
                    : isBooking
                      ? ar ? 'جاري حجز المقعد...' : 'Reserving seat...'
                      : soldOut
                        ? ar ? 'ممتلئ لهذه المغادرة' : 'Sold out for this departure'
                        : ar ? 'احجز المقعد' : 'Reserve seat'}
                </motion.button>
                <div
                  style={{
                    color: DS.sub,
                    fontSize: '0.76rem',
                    lineHeight: 1.55,
                    textAlign: 'right',
                    maxWidth: 320,
                  }}
                >
                  {hasBooking
                    ? bookingStatus === 'pending_driver'
                      ? ar
                        ? 'طلبك محفوظ في رحلاتي. واصل بحدثك لما السائق يؤكد المقعد وتفاصيل الصعود.'
                        : 'Your request is already saved in My Trips. Wasel will update you when the driver confirms the seat and boarding details.'
                      : ar
                        ? 'مقعدك محفوظ في رحلاتي. إذا تغيرت المغادرة، واصل ببعت تحديث قبل الموعد.'
                        : 'Your seat is stored in My Trips. If the departure shifts, Wasel sends an update before departure.'
                    : soldOut
                      ? ar
                        ? 'هذه المغادرة ممتلئة حالياً. افتح بديل الباص أو جرب مسار قريب لحد ما يتحدث الخط.'
                        : 'This departure is full right now. Open bus fallback or try another nearby corridor while this route refreshes.'
                      : ar
                        ? 'حجزك بحفظ المقعد وتفاصيل الصعود. إذا تغير المسار، واصل بحدثك والدعم بساعدك.'
                        : 'Your booking saves the seat and boarding details. If the route changes, Wasel updates you and support can help.'}
                </div>
                <div style={{ display: 'flex', gap: 8 }}>
                  <a
                    href={`https://wa.me/${ride.driver.phone.replace(/[^0-9]/g, '')}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    style={{
                      ...pill(C.green),
                      padding: '6px 14px',
                      fontSize: '0.75rem',
                      textDecoration: 'none',
                      cursor: 'pointer',
                    }}
                  >
                    <svg
                      width="12"
                      height="12"
                      viewBox="0 0 24 24"
                      fill={C.green}
                      style={{ marginRight: 4 }}
                    >
                      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
                    </svg>
                    WhatsApp
                  </a>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
