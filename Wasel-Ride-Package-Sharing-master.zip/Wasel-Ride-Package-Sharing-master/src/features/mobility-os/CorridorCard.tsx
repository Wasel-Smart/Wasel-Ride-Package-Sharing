import { ArrowDownRight, ArrowUpRight, MoveRight } from 'lucide-react';
import { C, FM, R, SH } from '../../utils/wasel-ds';
import type { CorridorProjection, PriceDirection } from './model';
import { tx } from '../../locales/tx';

function money(value: number): string {
  return `${value.toFixed(2)} JOD`;
}

function percent(value: number): string {
  return `${Math.round(value * 100)}%`;
}

function directionIcon(direction: PriceDirection) {
  if (direction === 'up') return <ArrowUpRight size={14} />;
  if (direction === 'down') return <ArrowDownRight size={14} />;
  return <MoveRight size={14} />;
}

function directionColor(direction: PriceDirection): string {
  if (direction === 'up') return C.gold;
  if (direction === 'down') return C.green;
  return C.textMuted;
}

export interface CorridorCardProps {
  projection: CorridorProjection;
  selected: boolean;
  onSelect: () => void;
}

export function CorridorCard({ projection, selected, onSelect }: CorridorCardProps) {
  const seatDirection = directionColor(projection.seat_price_direction);
  const cargoDirection = directionColor(projection.cargo_price_direction);

  return (
    <button
      data-testid={`mobility-os-corridor-${projection.corridor.id}`}
      type="button"
      onClick={onSelect}
      style={{
        width: '100%',
        textAlign: 'left',
        borderRadius: R.xxl,
        border: `1px solid ${selected ? C.cyan : C.border}`,
        background: selected ? `linear-gradient(180deg, ${C.cyanDim}, ${C.card})` : C.card,
        boxShadow: selected ? SH.blueL : SH.card,
        padding: 18,
        color: C.text,
        cursor: 'pointer',
        display: 'grid',
        gap: 14,
      }}
    >
      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          gap: 12,
          alignItems: 'flex-start',
        }}
      >
        <div>
          <div
            style={{
              fontSize: '0.74rem',
              letterSpacing: '0.14em',
              textTransform: 'uppercase',
              color: C.textMuted,
            }}
          >
            {tx('corridorCard.corridor_instrument')}
          </div>
          <div style={{ marginTop: 6, fontSize: '1.08rem', fontWeight: 900 }}>
            {projection.corridor.origin} <span style={{ color: C.textMuted }}>{'->'}</span>{' '}
            {projection.corridor.destination}
          </div>
          <div style={{ marginTop: 5, color: C.textMuted, fontSize: '0.8rem' }}>
            {projection.corridor.distance_km} {tx('corridorCard.km')}
            {projection.corridor.travel_time_min} {tx('services.publicBus.minutes')}
          </div>
        </div>
        <div
          style={{
            padding: '8px 10px',
            borderRadius: R.full,
            border: `1px solid ${C.border}`,
            background: C.elevated,
            fontFamily: FM,
            fontSize: '0.74rem',
            color: C.cyan,
          }}
        >
          {projection.corridor.id}
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, minmax(0, 1fr))', gap: 10 }}>
        {[
          ['Seats Available', String(projection.seats_available)],
          ['Cargo Available', `${projection.cargo_available_kg} kg`],
          ['Utilization', percent(projection.utilization)],
          ['Demand Pressure', projection.demand_pressure.toFixed(2)],
        ].map(([label, value]) => (
          <div
            key={label}
            style={{
              borderRadius: 16,
              border: `1px solid ${C.borderFaint}`,
              background: C.elevated,
              padding: '12px 12px 10px',
            }}
          >
            <div
              style={{
                color: C.textMuted,
                fontSize: '0.7rem',
                letterSpacing: '0.08em',
                textTransform: 'uppercase',
              }}
            >
              {label}
            </div>
            <div style={{ marginTop: 6, fontSize: '0.98rem', fontWeight: 800 }}>{value}</div>
          </div>
        ))}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, minmax(0, 1fr))', gap: 12 }}>
        <div
          style={{
            borderRadius: 18,
            border: `1px solid ${C.goldDim}`,
            background: C.goldDim,
            padding: '12px 13px',
          }}
        >
          <div
            style={{
              color: C.textMuted,
              fontSize: '0.7rem',
              letterSpacing: '0.08em',
              textTransform: 'uppercase',
            }}
          >
            {tx('corridorCard.dynamic_seat_price')}
          </div>
          <div
            style={{
              marginTop: 6,
              display: 'flex',
              alignItems: 'center',
              gap: 8,
              fontWeight: 900,
              color: C.gold,
            }}
          >
            {money(projection.dynamic_seat_price)}
            <span style={{ display: 'inline-flex', alignItems: 'center', color: seatDirection }}>
              {directionIcon(projection.seat_price_direction)}
            </span>
          </div>
        </div>
        <div
          style={{
            borderRadius: 18,
            border: `1px solid ${C.greenDim}`,
            background: C.greenDim,
            padding: '12px 13px',
          }}
        >
          <div
            style={{
              color: C.textMuted,
              fontSize: '0.7rem',
              letterSpacing: '0.08em',
              textTransform: 'uppercase',
            }}
          >
            {tx('corridorCard.dynamic_cargo_price')}
          </div>
          <div
            style={{
              marginTop: 6,
              display: 'flex',
              alignItems: 'center',
              gap: 8,
              fontWeight: 900,
              color: C.green,
            }}
          >
            {money(projection.dynamic_cargo_price)}
            <span style={{ display: 'inline-flex', alignItems: 'center', color: cargoDirection }}>
              {directionIcon(projection.cargo_price_direction)}
            </span>
          </div>
        </div>
      </div>
    </button>
  );
}
