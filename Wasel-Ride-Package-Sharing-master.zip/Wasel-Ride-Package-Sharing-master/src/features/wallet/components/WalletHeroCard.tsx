import { ArrowUpRight, Clock, Eye, EyeOff, Gift, Plus, Send } from 'lucide-react';
import { motion } from 'framer-motion';
import { Button } from '../../../components/ui/button';
import { WaselColors } from '../../../tokens/wasel-tokens';
import { C } from '../../../utils/wasel-ds';

type WalletHeroCardProps = {
  balance: number;
  balanceVisible: boolean;
  canTopUp: boolean;
  pendingBalance: number;
  rewardsBalance: number;
  t: Record<string, string>;
  onShowSend: () => void;
  onShowTopUp: () => void;
  onShowWithdraw: () => void;
  onToggleBalance: () => void;
};

export function WalletHeroCard({
  balance,
  balanceVisible,
  canTopUp,
  pendingBalance,
  rewardsBalance,
  t,
  onShowSend,
  onShowTopUp,
  onShowWithdraw,
  onToggleBalance,
}: WalletHeroCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="relative overflow-hidden rounded-xl p-6"
      style={{
        background: `linear-gradient(135deg, ${C.cardSolid} 0%, ${C.card2} 56%, ${C.bgAlt} 100%)`,
        border: `1px solid ${WaselColors.teal}20`,
        boxShadow: '0 14px 34px rgba(0,0,0,0.28)',
      }}
    >
      <div
        aria-hidden="true"
        className="absolute inset-0"
        style={{
          background: `linear-gradient(120deg, ${C.cyanDim}, transparent 36%, ${C.elevated})`,
          pointerEvents: 'none',
        }}
      />

      <div className="relative z-10">
        <div className="mb-1 flex items-center justify-between">
          <span className="text-sm text-slate-400">{t.balance}</span>
          <button
            type="button"
            onClick={onToggleBalance}
            className="text-slate-400 transition-colors hover:text-white"
          >
            {balanceVisible ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
          </button>
        </div>

        <div className="mb-4 flex items-baseline gap-2">
          <span className="text-3xl font-bold text-white tabular-nums">
            {balanceVisible ? balance.toFixed(2) : t.maskedBalance}
          </span>
          <span className="text-lg font-medium text-slate-400">{t.jod}</span>
        </div>

        <div className="mb-6 flex gap-4">
          {pendingBalance > 0 && (
            <div className="flex items-center gap-1.5">
              <Clock className="h-3.5 w-3.5 text-yellow-400" />
              <span className="text-xs text-yellow-400">
                {t.pending}: {balanceVisible ? pendingBalance.toFixed(2) : t.maskedShort} {t.jod}
              </span>
            </div>
          )}
          {rewardsBalance > 0 && (
            <div className="flex items-center gap-1.5">
              <Gift className="h-3.5 w-3.5 text-purple-400" />
              <span className="text-xs text-purple-400">
                {t.rewards}: {balanceVisible ? rewardsBalance.toFixed(2) : t.maskedShort} {t.jod}
              </span>
            </div>
          )}
        </div>

        <div className="grid grid-cols-3 gap-3">
          <Button
            onClick={onShowTopUp}
            disabled={!canTopUp}
            className="h-12 rounded-xl text-sm font-semibold disabled:opacity-60"
            style={{ background: WaselColors.teal }}
          >
            <Plus className="mr-1.5 h-4 w-4" />
            {t.addMoney}
          </Button>
          <Button
            onClick={onShowWithdraw}
            variant="outline"
            className="h-12 rounded-xl border-slate-600 text-sm font-semibold text-slate-200 hover:bg-slate-700/50"
          >
            <ArrowUpRight className="mr-1.5 h-4 w-4" />
            {t.withdraw}
          </Button>
          <Button
            onClick={onShowSend}
            variant="outline"
            className="h-12 rounded-xl border-slate-600 text-sm font-semibold text-slate-200 hover:bg-slate-700/50"
          >
            <Send className="mr-1.5 h-4 w-4" />
            {t.sendMoney}
          </Button>
        </div>
        {!canTopUp ? <p className="mt-3 text-xs text-slate-400">{t.topUpUnavailableHint}</p> : null}
      </div>
    </motion.div>
  );
}
