/**
 * Shared primitives for all Wasel service pages.
 *
 * Extracted from the monolithic WaselServicePage.tsx so that
 * FindRidePage, OfferRidePage, BusPage, and PackagesPage can each
 * live in their own file without duplicating DS bindings, city
 * data, storage helpers, or the Protected / PageShell wrappers.
 */
import type { ReactNode } from 'react';
import { ProtectedPagePreview } from '../../components/system/ProtectedPagePreview';
import { useLocalAuth } from '../../contexts/LocalAuth';
import { useLanguage } from '../../contexts/LanguageContext';
import { PAGE_DS } from '../../styles/wasel-page-theme';
import { C, GRAD, GRAD_HERO, R, SH } from '../../utils/wasel-ds';

// Design-system shorthand
export const DS = PAGE_DS;

export const r = (px = 12) => `${px}px`;

export const pill = (color: string) => ({
  display: 'inline-flex' as const,
  alignItems: 'center' as const,
  gap: 4,
  padding: '4px 11px',
  borderRadius: '99px',
  background: `${color}15`,
  border: `1px solid ${color}30`,
  fontSize: '0.68rem',
  fontWeight: 800,
  color,
});

// Jordan city coordinates
export const CITY_COORDS: Record<string, { lat: number; lng: number }> = {
  Amman: { lat: 31.9539, lng: 35.9106 },
  Aqaba: { lat: 29.5321, lng: 35.006 },
  Irbid: { lat: 32.5568, lng: 35.8479 },
  Zarqa: { lat: 32.0728, lng: 36.088 },
  'Dead Sea': { lat: 31.559, lng: 35.4732 },
  Karak: { lat: 31.1854, lng: 35.7048 },
  Madaba: { lat: 31.7196, lng: 35.7939 },
  Petra: { lat: 30.3285, lng: 35.4444 },
  Jerash: { lat: 32.2744, lng: 35.8961 },
  Mafraq: { lat: 32.3429, lng: 36.208 },
  Salt: { lat: 32.0392, lng: 35.7272 },
  'Wadi Rum': { lat: 29.5734, lng: 35.4196 },
  Ajloun: { lat: 32.3333, lng: 35.7528 },
  "Ma'in": { lat: 31.6796, lng: 35.6217 },
};

export const CITIES = [
  'Amman',
  'Aqaba',
  'Irbid',
  'Zarqa',
  'Dead Sea',
  'Karak',
  'Madaba',
  'Petra',
  'Jerash',
  'Mafraq',
  'Salt',
  'Wadi Rum',
  'Ajloun',
  "Ma'in",
];

export function resolveCityCoord(city: string): { lat: number; lng: number } {
  return CITY_COORDS[city] ?? CITY_COORDS.Amman ?? { lat: 31.9539, lng: 35.9106 };
}

export function midpoint(
  a: { lat: number; lng: number },
  b: { lat: number; lng: number },
): { lat: number; lng: number } {
  return { lat: (a.lat + b.lat) / 2, lng: (a.lng + b.lng) / 2 };
}

// localStorage helpers
export function readStoredStringList(key: string): string[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = window.localStorage.getItem(key);
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed)
      ? parsed.filter((item): item is string => typeof item === 'string')
      : [];
  } catch {
    return [];
  }
}

export function writeStoredStringList(key: string, values: string[]) {
  if (typeof window === 'undefined') return;
  window.localStorage.setItem(key, JSON.stringify(values));
}

export function readStoredObject<T>(key: string, fallback: T): T {
  if (typeof window === 'undefined') return fallback;
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? { ...fallback, ...JSON.parse(raw) } : fallback;
  } catch {
    return fallback;
  }
}

// Auth guard
export function Protected({ children }: { children: ReactNode }) {
  const { user } = useLocalAuth();

  if (!user) {
    return <ProtectedPagePreview />;
  }
  return <>{children}</>;
}

// Page shell (responsive layout wrapper)
export function PageShell({ children }: { children: ReactNode }) {
  const { language } = useLanguage();
  const ar = language === 'ar';
  return (
    <div
      style={{
        minHeight: 'var(--app-min-height)',
        background: `linear-gradient(180deg, ${C.bgDeep} 0%, ${DS.bg} 42%, ${C.bgAlt} 100%)`,
        fontFamily: DS.F,
        direction: ar ? 'rtl' : 'ltr',
        color: C.text,
        position: 'relative',
        overflow: 'hidden',
      }}
    >
      <style>{`
        :root { color-scheme: dark; scroll-behavior: smooth; }
        .w-focus:focus-visible{ outline:none; box-shadow:0 0 0 3px ${C.cyanGlow}; }
        .w-focus-gold:focus-visible{ outline:none; box-shadow:0 0 0 3px ${C.goldDim}; }
        @media (prefers-reduced-motion: reduce) {
          *, *::before, *::after {
            animation-duration: 0.01ms !important;
            animation-iteration-count: 1 !important;
            transition-duration: 0.01ms !important;
            scroll-behavior: auto !important;
          }
        }
        @media(max-width:899px){
          .sp-inner{ padding:16px !important; }
          .sp-2col { grid-template-columns:1fr !important; }
          .sp-3col { grid-template-columns:1fr !important; }
          .sp-4col { grid-template-columns:1fr 1fr !important; }
          .sp-head  { padding:20px 16px !important; border-radius:16px !important; }
          .sp-search-grid { grid-template-columns:1fr !important; gap:10px !important; }
          .sp-sort-bar { overflow-x:auto !important; -webkit-overflow-scrolling:touch !important; padding-bottom:6px !important; flex-wrap:nowrap !important; scrollbar-width:none !important; }
          .sp-sort-bar::-webkit-scrollbar { display:none; }
          .sp-sort-btn { flex-shrink:0 !important; white-space:nowrap !important; }
          .sp-results-header { flex-direction:column !important; align-items:flex-start !important; gap:12px !important; }
          .sp-book-btn { min-height:44px !important; }
          .sp-ride-card-body { padding:16px !important; }
          .sp-summary-grid { grid-template-columns:1fr !important; }
          .sp-bus-card-grid { grid-template-columns:1fr !important; }
          .sp-empty-actions { grid-template-columns:1fr !important; }
          .sp-side-column { position:static !important; }
          .sp-shell-grid { opacity: 0.12 !important; }
        }
        @media(max-width:480px){
          .sp-4col { grid-template-columns:1fr !important; }
          .sp-head-inner { flex-direction:column !important; gap:12px !important; align-items:flex-start !important; }
          .sp-head-btn { width:100% !important; display:flex !important; justify-content:center !important; }
          .sp-inner { padding:12px !important; }
          .sp-corridor-snapshot { grid-template-columns:1fr !important; }
        }
      `}</style>
      <div
        aria-hidden="true"
        className="sp-shell-grid"
        style={{
          position: 'fixed',
          inset: 0,
          backgroundImage: `linear-gradient(${C.borderFaint} 1px, transparent 1px), linear-gradient(90deg, ${C.borderFaint} 1px, transparent 1px)`,
          backgroundSize: '72px 72px',
          maskImage:
            'linear-gradient(180deg, transparent 0%, black 12%, black 78%, transparent 100%)',
          pointerEvents: 'none',
          opacity: 0.08,
        }}
      />
      <div
        className="sp-inner"
        style={{
          position: 'relative',
          maxWidth: 1120,
          margin: '0 auto',
          padding: '24px 16px 36px',
        }}
      >
        {children}
      </div>
    </div>
  );
}

// Section header
export function SectionHead({
  emoji,
  title,
  titleAr,
  sub,
  subAr,
  color = DS.cyan,
  action,
}: {
  emoji: ReactNode;
  title: string;
  titleAr?: string;
  sub?: string;
  subAr?: string;
  color?: string;
  action?: { label: string; labelAr?: string; onClick: () => void };
}) {
  const { language } = useLanguage();
  const ar = language === 'ar';
  const displayTitle = ar && titleAr ? titleAr : title;
  const displaySub = ar && subAr ? subAr : sub;

  return (
    <div
      className="sp-head"
      style={{
        background: GRAD_HERO,
        borderRadius: R.xxl,
        padding: '26px 24px',
        marginBottom: 20,
        position: 'relative',
        overflow: 'hidden',
        border: `1px solid ${color}20`,
        boxShadow: SH.lg,
      }}
    >
      <div
        style={{
          position: 'absolute',
          inset: 0,
          background: `linear-gradient(120deg, ${color}12, transparent 36%, ${C.elevated})`,
          pointerEvents: 'none',
        }}
      />
      <div
        className="sp-head-inner"
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          position: 'relative',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
          <div
            style={{
              width: 58,
              height: 58,
              borderRadius: R.xl,
              background: `${color}18`,
              border: `1.5px solid ${color}34`,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color,
              flexShrink: 0,
            }}
          >
            {emoji}
          </div>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 4 }}>
              <h1
                style={{
                  fontSize: '1.62rem',
                  fontWeight: 950,
                  color: C.text,
                  margin: 0,
                  letterSpacing: 0,
                }}
              >
                {displayTitle}
              </h1>
            </div>
            <div style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'center', gap: 8 }}>
              {displaySub && (
                <span style={{ color: C.textMuted, fontSize: '0.78rem' }}>{displaySub}</span>
              )}
            </div>
          </div>
        </div>
        {action && (
          <button
            onClick={action.onClick}
            className="sp-head-btn"
            style={{
              height: 44,
              padding: '0 22px',
              borderRadius: R.full,
              border: 'none',
              background: GRAD,
              color: C.bgDeep,
              fontWeight: 900,
              fontSize: '0.875rem',
              boxShadow: SH.blueL,
              cursor: 'pointer',
              flexShrink: 0,
            }}
          >
            {ar && action.labelAr ? action.labelAr : action.label}
          </button>
        )}
      </div>
    </div>
  );
}

// Core experience banner
export function CoreExperienceBanner({
  title,
  detail,
  tone = DS.cyan,
}: {
  title: string;
  detail: string;
  tone?: string;
}) {
  const { t } = useLanguage();
  return (
    <div
      style={{
        display: 'flex',
        gap: 10,
        alignItems: 'flex-start',
        background: `linear-gradient(135deg, ${tone}0f, ${C.elevated})`,
        border: `1px solid ${tone}24`,
        borderRadius: R.xl,
        padding: '13px 14px',
        marginBottom: 18,
        boxShadow: '0 14px 34px rgba(0,0,0,0.22)',
      }}
    >
      <span style={{ ...pill(tone), flexShrink: 0 }}>{t('pageShared.live')}</span>
      <div>
        <div style={{ color: '#fff', fontWeight: 800, fontSize: '0.9rem', letterSpacing: 0 }}>
          {title}
        </div>
        <div style={{ color: DS.muted, fontSize: '0.76rem', lineHeight: 1.55, marginTop: 3 }}>
          {detail}
        </div>
      </div>
    </div>
  );
}
