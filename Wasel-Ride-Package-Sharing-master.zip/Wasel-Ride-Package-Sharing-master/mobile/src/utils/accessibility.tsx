import React from 'react';
import { PixelRatio, StyleSheet, Text, View, type StyleProp, type TextStyle, type ViewStyle } from 'react-native';

export function getFontSize(size: number): number {
  return size * PixelRatio.getFontScale();
}

export const accessibilityStyles = StyleSheet.create({
  screenReaderOnly: {
    position: 'absolute',
    width: 1,
    height: 1,
    opacity: 0,
  },
  focusRing: {
    borderWidth: 2,
    borderColor: '#00E5FF',
    borderStyle: 'solid',
  },
  touchTargetMinimum: {
    minHeight: 48,
    minWidth: 48,
  },
  highContrastText: {
    color: '#07111F',
    fontWeight: '900',
  },
});

export const accessibilityLabels = {
  rideMap: 'خريطة تفاعلية بتعرض موقع مشوارك',
  driverMarker: 'علامة موقع السائق',
  destinationMarker: 'علامة موقع الوجهة',
  callDriver: 'اتصل بالسائق',
  shareLocation: 'شارك موقعك المباشر',
  refreshRide: 'حدّث حالة المشوار',
};

export function AccessibleText({
  children,
  style,
  accessibilityLabel,
  accessibilityHint,
  accessible = true,
}: {
  children: React.ReactNode;
  style?: StyleProp<TextStyle>;
  accessibilityLabel?: string;
  accessibilityHint?: string;
  accessible?: boolean;
}) {
  return (
    <Text
      style={style}
      accessible={accessible}
      accessibilityLabel={accessibilityLabel}
      accessibilityHint={accessibilityHint}
    >
      {children}
    </Text>
  );
}

export function AccessibleView({
  children,
  style,
  accessibilityLabel,
  accessibilityRole,
  accessibilityState,
  accessible = true,
}: {
  children: React.ReactNode;
  style?: StyleProp<ViewStyle>;
  accessibilityLabel?: string;
  accessibilityRole?: string;
  accessibilityState?: Record<string, unknown>;
  accessible?: boolean;
}) {
  return (
    <View
      style={style}
      accessible={accessible}
      accessibilityLabel={accessibilityLabel}
      accessibilityRole={accessibilityRole as unknown as never}
      accessibilityState={accessibilityState as unknown as never}
    >
      {children}
    </View>
  );
}